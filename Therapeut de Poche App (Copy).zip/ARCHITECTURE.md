# Thérapeute de Poche - Architecture & Spécifications

## Vue d'ensemble

**Thérapeute de Poche** est une plateforme de rééducation intelligente qui connecte les thérapeutes et leurs patients pour améliorer l'efficacité des thérapies et réduire la durée de réhabilitation.

## Principes de Design

### Interface Thérapeute
- **Style**: Clean Medical - Interface épurée avec cartes blanches sur fond gris clair
- **Navigation**: Barre latérale gauche fixe
- **Objectif**: Efficacité et précision dans la gestion des patients

### Interface Patient
- **Style**: Empathique et encourageant
- **Couleurs**: Vert menthe (#10b981), bleu ciel (#3b82f6), jaune doré (badges)
- **Typographie**: Grande taille pour accessibilité (seniors)
- **Philosophie**: Zéro culpabilité - on ne montre que le chemin parcouru

## Sitemap

### A. Interface THÉRAPEUTE

```
/therapist
├── / (Dashboard)
│   ├── Statistiques globales
│   ├── Alertes douleur (≥8/10)
│   └── Liste patients récents
│
├── /patients (Liste des patients)
│   ├── Recherche et filtres
│   └── /patients/:id (Fiche patient)
│       ├── Suivi et graphiques
│       ├── Programmes assignés
│       └── Historique feedbacks
│
├── /templates (Bibliothèque de templates)
│   ├── Liste des programmes types
│   └── /templates/:id (Éditeur de template)
│       ├── Titre et description
│       └── Sélection d'exercices
│
└── /exercises (Bibliothèque d'exercices)
    ├── Grille avec filtres (Ergo/Physio)
    ├── Recherche
    └── Ajout/Édition d'exercices
```

### B. Interface PATIENT

```
/patient/:patientId
├── / (Dashboard patient)
│   ├── Séances à faire aujourd'hui
│   ├── Progression de la semaine
│   └── Séances terminées
│
├── /session/:programId (Player de séance)
│   ├── Enchaînement d'exercices
│   ├── Vidéos et paramètres
│   └── Feedback post-séance
│
├── /progress (Progression)
│   ├── Statistiques
│   ├── Graphiques d'évolution
│   └── Calendrier de succès
│
└── /achievements (Mes succès)
    ├── Badges obtenus
    ├── Badges à débloquer
    └── Percentile d'activité
```

## Architecture des Données

### Modèles Principaux

#### Exercise
```typescript
{
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  type: 'physio' | 'ergo';
  thumbnail: string;
}
```

#### ProgramTemplate
```typescript
{
  id: string;
  title: string;
  description: string;
  exerciseIds: string[]; // Référence aux exercices
}
```

#### PersonalizedProgram
```typescript
{
  id: string;
  templateId: string;
  patientId: string;
  type: 'physio' | 'ergo';
  frequency: number; // Séances par semaine
  exercises: PersonalizedExercise[];
  createdAt: Date;
}
```

#### PersonalizedExercise
```typescript
{
  exerciseId: string;
  charge?: number; // kg
  duration?: number; // minutes
  repetitions?: number;
}
```

#### SessionFeedback
```typescript
{
  id: string;
  programId: string;
  patientId: string;
  date: Date;
  painLevel: number; // 0-10
  comment: string;
  completed: boolean;
}
```

#### Patient
```typescript
{
  id: string;
  firstName: string;
  lastName: string;
  lastFeedback?: Date;
  adherenceRate: number; // Pourcentage
}
```

#### Badge
```typescript
{
  id: string;
  title: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: Date;
}
```

## Flux de Données Clés

### 1. Création d'un Programme Template
1. Thérapeute crée un template (titre + description)
2. Sélectionne des exercices depuis la bibliothèque
3. Template sauvegardé (structure fixe)

### 2. Assignation à un Patient (Template → Personnalisé)
1. Thérapeute sélectionne un template
2. Assigne à un patient
3. **Création d'une Instance Personnalisée**
4. Définit les variables:
   - Fréquence (x fois/semaine)
   - Charge (kg)
   - Durée (min)
   - Répétitions
5. Peut ajouter/retirer des exercices spécifiques

### 3. Séance Patient
1. Patient voit les programmes assignés
2. Lance une séance (player)
3. Enchaînement des exercices avec vidéos
4. Feedback post-séance:
   - Slider douleur (0-10)
   - Commentaire libre

### 4. Système d'Alerte Douleur
- **Trigger**: Feedback patient avec douleur ≥ 8/10
- **Action**: 
  - Notification immédiate au thérapeute
  - Mise en évidence rouge sur le dashboard
  - Bouton "Adapter le programme"

## Fonctionnalités Spécifiques

### Côté Thérapeute

#### Dashboard
- Vue d'ensemble des patients actifs
- Alertes critiques (douleur ≥8/10)
- Statistiques globales (adhésion, séances)

#### Gestion Patient
- Suivi individuel avec graphiques
- Modification en temps réel des programmes
- Historique complet des feedbacks

#### Bibliothèque d'Exercices
- Grille visuelle avec miniatures
- Filtres par type (Physio/Ergo)
- Recherche textuelle
- Ajout avec vidéos

### Côté Patient

#### Dashboard
- Suggestion directe: "Lancer la séance"
- Progression de la semaine (jauge)
- Historique positif uniquement

#### Player de Séance
- Interface immersive (fond sombre)
- Vidéo + paramètres (durée, charge, reps)
- Progression claire
- Encouragements visuels

#### Progression
- Graphiques d'évolution de la douleur
- Activité hebdomadaire
- Calendrier de succès (seulement le positif)

#### Badges & Gamification
- Badges obtenus (colorés)
- Badges à débloquer (grisés)
- Social proof: "Top 15% des patients"
- Messages d'encouragement

## Principes UX Clés

### Pour les Patients Hospitalisés

#### 🚫 À ÉVITER
- Culpabilisation pour séances manquées
- Rappels négatifs
- Comptes à rebours stressants
- Messages anxiogènes

#### ✅ À FAVORISER
- Célébration des réussites
- Encouragements constants
- Visualisation positive
- Messages empathiques
- Accessibilité (grande typo)

### Exemples de Messages

**Bon** ✅
- "Bravo ! Chaque effort compte"
- "Vous faites partie des plus actifs"
- "Félicitations pour cette séance !"

**Mauvais** ❌
- "Vous avez manqué 3 séances"
- "Votre retard s'accumule"
- "Attention, objectif non atteint"

## Technologies Utilisées

- **Framework**: React avec TypeScript
- **Routing**: React Router (Data Mode)
- **Styling**: Tailwind CSS v4
- **UI Components**: Radix UI / shadcn/ui
- **Charts**: Recharts
- **Icons**: Lucide React

## Chemins des Fichiers

```
/src/app/
├── data/
│   └── mockData.ts          # Données de démonstration
├── layouts/
│   ├── RootLayout.tsx
│   ├── TherapistLayout.tsx  # Layout avec sidebar
│   └── PatientLayout.tsx    # Layout avec bottom nav
├── pages/
│   ├── Landing.tsx
│   ├── therapist/
│   │   ├── Dashboard.tsx
│   │   ├── PatientsList.tsx
│   │   ├── PatientDetail.tsx
│   │   ├── TemplatesLibrary.tsx
│   │   ├── TemplateEditor.tsx
│   │   └── ExercisesLibrary.tsx
│   └── patient/
│       ├── Dashboard.tsx
│       ├── SessionPlayer.tsx
│       ├── Progress.tsx
│       └── Achievements.tsx
├── components/
│   └── ui/                  # Composants UI réutilisables
├── routes.ts                # Configuration du routing
└── App.tsx                  # Point d'entrée
```

## Écrans Clés Détaillés

### 1. Dashboard Thérapeute - Alertes
**Composant**: Bannière rouge en haut
```
🚨 Alerte Douleur : Jean D. a signalé 9/10 lors de sa séance de Physio ce matin
[Adapter le programme →]
```

### 2. Accueil Patient - Lancement
**Message**: "Bonjour [Prénom], prêt pour votre séance de Physio ?"
**Action**: Un seul gros bouton "Lancer la séance (15 min)"
**Visuel**: Jauge circulaire de progression hebdomadaire

### 3. Onglet "Mes Succès" - Motivation
**Message**: "Félicitations ! Vous êtes plus assidu que 80% des patients du service."
**Composant**: Grille de badges avec icons emoji
**Exemples**: "7 jours de suite" 🔥, "Champion de l'Ergo" 🏆, "Premier pas" ⭐

## Points d'Extension Future

1. **Authentification réelle** (actuellement mock)
2. **Backend Supabase** pour persistance
3. **Notifications push** pour alertes thérapeute
4. **Upload de vidéos** pour exercices
5. **Export PDF** des rapports patient
6. **Messagerie** thérapeute-patient
7. **Rappels intelligents** (non culpabilisants)
8. **Multi-langue**

## Notes de Développement

- Actuellement en mode **démo** avec données mock
- Routes patient utilisent un ID dynamique (`/patient/:patientId`)
- Pour tester: utilisez `/patient/p1` (Jean Dupont)
- Les modifications de programmes ne sont pas persistées (UX seulement)
- Les vidéos sont des placeholders

---

**Version**: 1.0
**Date**: Mars 2026
**Auteur**: Architecture pour Figma Make
