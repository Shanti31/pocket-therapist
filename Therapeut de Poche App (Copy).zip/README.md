# Thérapeute de Poche 💊

Une plateforme de rééducation intelligente qui connecte les thérapeutes et leurs patients pour améliorer l'efficacité des thérapies et réduire la durée de réhabilitation.

## 🎯 Objectif

Faciliter la rééducation des patients hospitalisés en :
- Permettant aux thérapeutes de créer et personnaliser des programmes d'exercices
- Offrant aux patients une interface encourageante pour suivre leurs séances
- Assurant un suivi en temps réel avec alertes pour les cas critiques
- Réduisant la durée des thérapies grâce à une meilleure adhésion

## 🚀 Démarrage Rapide

### Page d'accueil
Visitez `/` pour choisir entre :
- **Interface Thérapeute** : Gestion des patients et programmes
- **Interface Patient** : Réalisation des exercices et suivi

### Démo Rapide

**En tant que Thérapeute** :
1. Accédez à `/therapist`
2. Consultez le dashboard avec les alertes
3. Gérez vos patients dans `/therapist/patients`
4. Créez des templates dans `/therapist/templates`
5. Gérez la bibliothèque d'exercices dans `/therapist/exercises`

**En tant que Patient** :
1. Accédez à `/patient/p1` (Jean Dupont)
2. Lancez une séance depuis le dashboard
3. Complétez les exercices et donnez votre feedback
4. Consultez votre progression dans l'onglet "Progression"
5. Découvrez vos badges dans "Mes Succès"

## 📱 Navigation

### Interface Thérapeute

```
/therapist
├── /                        Dashboard avec alertes et statistiques
├── /patients                Liste de tous les patients
├── /patients/:id            Détail d'un patient avec suivi
├── /templates               Bibliothèque de programmes templates
├── /templates/new           Créer un nouveau template
├── /templates/:id           Modifier un template
└── /exercises               Bibliothèque d'exercices
```

### Interface Patient

```
/patient/:patientId
├── /                        Dashboard patient (séances du jour)
├── /session/:programId      Player de séance interactive
├── /progress                Graphiques de progression
└── /achievements            Badges et réussites
```

## 🎨 Caractéristiques

### Pour les Thérapeutes
- ✅ Dashboard avec alertes en temps réel (douleur ≥8/10)
- ✅ Gestion complète des patients
- ✅ Création de templates de programmes
- ✅ Personnalisation par patient (charge, durée, fréquence)
- ✅ Bibliothèque d'exercices avec filtres
- ✅ Graphiques de suivi de la douleur
- ✅ Historique des feedbacks patients

### Pour les Patients
- ✅ Interface encourageante et accessible
- ✅ Lancement rapide des séances
- ✅ Player interactif avec vidéos (placeholder)
- ✅ Feedback post-séance (douleur + commentaire)
- ✅ Graphiques de progression
- ✅ Système de badges et gamification
- ✅ Messages motivants (0 culpabilité)
- ✅ Percentile d'activité

## 🏗️ Architecture Technique

### Stack
- **React** avec TypeScript
- **React Router** (Data Mode)
- **Tailwind CSS v4**
- **Recharts** pour les graphiques
- **Radix UI** / shadcn/ui pour les composants
- **Lucide React** pour les icônes

### Structure
```
/src/app/
├── data/mockData.ts         Données de démonstration
├── layouts/                 Layouts avec navigation
├── pages/                   Pages de l'application
│   ├── therapist/          Pages thérapeute
│   └── patient/            Pages patient
├── components/ui/          Composants UI réutilisables
├── routes.ts               Configuration routing
└── App.tsx                 Point d'entrée
```

## 📊 Données de Démonstration

### Patients
- **Jean Dupont** (p1) : 85% adhésion, alerte douleur récente
- **Marie Martin** (p2) : 92% adhésion
- **Pierre Durand** (p3) : 68% adhésion
- **Sophie Leclerc** (p4) : 95% adhésion

### Programmes Templates
- **Post-op Hanche Standard** : 4 exercices de physio
- **Ergothérapie Main** : 2 exercices de préhension
- **Mobilité Générale** : 3 exercices mixtes

### Exercices
- 6 exercices au total
- Types : Physiothérapie et Ergothérapie
- Avec images et descriptions

## 🎯 Flux Utilisateur Clés

### 1. Thérapeute crée un programme personnalisé
1. Sélectionne un template dans `/therapist/templates`
2. L'assigne à un patient dans `/therapist/patients/:id`
3. Personnalise : fréquence, charge, durée, répétitions
4. Peut ajouter/retirer des exercices

### 2. Patient réalise une séance
1. Voit ses programmes sur `/patient/:id`
2. Clique sur "Lancer la séance"
3. Suit l'enchaînement d'exercices
4. Donne son feedback (douleur 0-10)
5. Gagne des badges selon ses progrès

### 3. Thérapeute reçoit une alerte
1. Patient signale douleur ≥8/10
2. Bannière rouge sur le dashboard thérapeute
3. Accès rapide pour adapter le programme
4. Modification en temps réel des paramètres

## 🎨 Principes de Design

### Interface Thérapeute
- Style épuré "Clean Medical"
- Navigation sidebar gauche
- Focus sur l'efficacité et les données

### Interface Patient
- Couleurs apaisantes (vert menthe, bleu ciel)
- Grande typographie (accessibilité seniors)
- Navigation bottom tab (mobile-first)
- **Philosophie**: Encourager, jamais culpabiliser

### Messages Patient
✅ **Bon** : "Bravo ! Chaque effort compte"
❌ **Mauvais** : "Vous avez manqué 3 séances"

## 🔧 Développement

### État Actuel
- Application complète et fonctionnelle
- Données en mode **mock** (pas de backend)
- Toutes les interactions UI sont implémentées
- Aucune persistance des modifications

### Prochaines Étapes
- [ ] Intégration backend (Supabase recommandé)
- [ ] Authentification réelle
- [ ] Upload de vidéos d'exercices
- [ ] Notifications push
- [ ] Persistance des modifications
- [ ] Export PDF des rapports

## 📄 Documentation

Consultez `/ARCHITECTURE.md` pour :
- Architecture détaillée des données
- Sitemap complet
- Spécifications UX
- Modèles de données TypeScript
- Guide d'extension

## 🎭 Démo Utilisateurs

### Compte Test Thérapeute
- Accès : `/therapist`
- Voir tous les patients et leurs feedbacks

### Compte Test Patient
- **Jean Dupont** : `/patient/p1`
  - 2 programmes actifs (Physio + Ergo)
  - Feedbacks avec alerte douleur
  - 4 badges dont 3 obtenus

## 💡 Cas d'Usage

### Scénario 1 : Post-opération de la hanche
1. Thérapeute assigne "Post-op Hanche Standard"
2. Patient fait 3 séances/semaine
3. Thérapeute suit l'évolution de la douleur
4. Adapte la charge selon les feedbacks

### Scénario 2 : Alerte douleur
1. Patient signale douleur 9/10
2. Thérapeute reçoit alerte rouge
3. Consulte le graphique d'évolution
4. Réduit la charge ou retire un exercice

### Scénario 3 : Motivation patient
1. Patient complète 7 jours consécutifs
2. Débloque badge "7 jours de suite" 🔥
3. Voit qu'il est dans le top 15%
4. Messages d'encouragement personnalisés

## 🌟 Points Forts

- ✨ **UX Empathique** : Zéro culpabilité, 100% encouragement
- 📊 **Suivi en Temps Réel** : Alertes instantanées pour douleur critique
- 🎮 **Gamification** : Badges et percentiles pour motiver
- 🔧 **Personnalisation** : Adaptation fine par patient
- 📱 **Mobile-First** : Interface patient optimisée mobile
- ♿ **Accessible** : Grande typo, messages clairs

---

**Version** : 1.0  
**Date** : Mars 2026  
**Plateforme** : Figma Make  

Pour toute question, consultez l'architecture détaillée dans `/ARCHITECTURE.md`
