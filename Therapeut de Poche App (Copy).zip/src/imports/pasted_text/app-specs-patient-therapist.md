1. Application PATIENT : Spécifications mises à jour
A. Écran Accueil (Dashboard)
Cartes "Séances du jour" : Ajout d'un indicateur visuel (icône horloge) avec la durée estimée de la séance (ex: "15 min") à côté du tag de thérapie.

B. Le Player de Séance (Flux révisé)
Étape 1 : Évaluation Avant-Séance. Avant même de voir le premier exercice, une modale ou un écran simple apparaît : "Comment évaluez-vous votre douleur avant de commencer ?" avec un slider horizontal utilisant des émojis (de 😃 "Aucune" à 😭 "Insupportable").

Étape 2 : L'interface de l'Exercice.

En-tête de la vidéo : Ajout du texte d'accroche standard : "Voici le mouvement que vous allez faire." juste au-dessus du player.

Progression masquée : Le "stepper" (ex: Exo 1/5) n'encombre plus l'écran. Il est placé dans une section dépliable (accordéon) en haut ou accessible via une petite icône "Info".

Gestion de l'abandon : La flèche "Retour" (en haut à gauche) agit comme le bouton "Abandonner". Au clic, une pop-up de confirmation s'ouvre : "Voulez-vous vraiment arrêter la séance ici ? Les exercices restants seront marqués comme non tentés."

Étape 3 : Exécution (Répétition vs Durée).

Si l'exo est au nombre de répétitions : Le patient regarde la vidéo, fait ses séries, puis clique sur "Fait, suivant".

Si l'exo est au chronomètre : Un gros bouton "Commencer l'exo" apparaît sous la vidéo. Au clic, un compte à rebours visuel démarre.

Étape 4 : Fin de séance & Redirection.

Après le feedback final (Douleur après séance avec émojis), la séance disparaît du dashboard "À faire" et bascule dans l'historique.

Action automatique : La modale de détail de cette séance (historique) s'ouvre automatiquement pour montrer au patient le résumé de ce qu'il vient d'accomplir.

C. Historique & Nouvelles Rubriques
Modale Historique : Contrainte stricte de design : la modale ne doit pas être scrollable. Elle doit être synthétique (icônes statuts, temps, douleur) pour tenir dans la vue de l'écran (Viewport).

NOUVEAU - Rubrique "Mes Notes" : Un onglet ou un bouton flottant permettant au patient d'ouvrir un champ de texte libre : "Une question, une remarque ? Notez-la ici pour en parler lors de votre prochaine visite avec votre thérapeute."

Onglet "Progression" (Refonte visuelle) :

Haut de page : Section "Mes Programmes" divisée en deux sous-onglets (Pilules/Tabs) : "Programmes Actifs" et "Historique Programmes".

Graphique 1 (Douleur) : Remplacement des moyennes abstraites par une belle courbe moderne montrant l'évolution de la douleur (Avant vs Après séance) au fil des jours.

Graphique 2 (Assiduité) : Un "Heatmap" type calendrier glissant sur 4 semaines (les 4 dernières semaines empilées). Les jours où une séance a été faite sont colorés (ex: vert), les jours de repos en gris clair.

💻 2. Application THÉRAPEUTE : Spécifications mises à jour
A. Dashboard & Liste Patients
Ajout Patient : Le bouton "+ Nouveau Patient" ouvre désormais une modale simple et rapide avec les champs : Prénom, Nom, Âge, Email.

Affichage de la liste : Bouton de bascule (Toggle) en haut à droite pour choisir entre Vue Liste (tableau compact) et Vue Grille (Cartes).

Contrainte "Vue Grille" : Les cartes patients doivent être orientées "Paysage" (rectangles horizontaux) et non verticales, pour éviter de prendre trop de place. Adapter le système de grille (ex: 3 cartes par ligne sur desktop).

Aperçu rapide (KPIs) : Directement sur la ligne ou la carte du patient, affichage des données de la dernière séance (Douleur, Adhésion type "4/5 exos").

B. Fiche Patient (Réorganisation complète)
La fiche patient devient un véritable tableau de bord individuel organisé de haut en bas selon vos 4 objectifs :

En-tête & Stats Globales (Vue d'ensemble) : Nom, Âge. Graphiques coulissants par mois (similaires à la vue patient) montrant l'adhésion et l'évolution de la douleur.

Dernières Séances (Le "Pouls" actuel) : Une mini-liste des 3-4 dernières séances avec les alertes de douleur bien visibles. Au clic sur une séance, ouverture de la Modale de Détail (montrant exactement quels exos ont été skippés ou bloquants).

Programme Actif & Configuration (L'Action) :

Affichage du programme en cours.

Règle de scope : Le thérapeute ne voit les options de modification (Ajout/Suppression d'exos, changement de charge/répétitions) uniquement s'il est le créateur ou l'assignataire de ce programme spécifique.

C. Bibliothèque de Templates
Affichage : Bascule Vue Liste / Vue Grille (comme pour les patients).

Cartes Templates : Suppression du bouton "Copier". Remplacement du bouton "Modifier" par un bouton "Voir plus" (qui mène à la Fiche du Template pour édition).

Sélection d'exercices (Modale) : Lors de l'édition d'un template, quand le thérapeute choisit des exercices à ajouter, il peut cliquer sur une icône "œil" ou sur la miniature pour ouvrir un Aperçu (Fiche Exo en modale) avec la vidéo jouable, garantissant qu'il sélectionne le bon mouvement.

D. Bibliothèque d'Exercices (Menu Latéral / Principal)
Cartes Exercices : Le texte de la description est tronqué (ex: 2 lignes max avec "...").

Interaction : Cliquer n'importe où sur la carte ouvre une Grande Modale contenant la vidéo complète, le titre, et la description intégrale lisible confortablement.