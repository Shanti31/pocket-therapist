import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Slider } from '../ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog';
import { AlertCircle, CheckCircle, SkipForward, X } from 'lucide-react';
import {
  getProgramById,
  getExerciseById,
  getTherapyTypeLabel,
} from '../../data/mockData';
import type { ExerciseStatus } from '../../types';

const PATIENT_ID = 'p-1';

interface ExerciseProgress {
  exerciseId: string;
  status: ExerciseStatus;
  skipReason?: string;
}

export function SessionPlayer() {
  const { programId } = useParams<{ programId: string }>();
  const navigate = useNavigate();

  const program = programId ? getProgramById(PATIENT_ID, programId) : null;

  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [exerciseProgress, setExerciseProgress] = useState<ExerciseProgress[]>(
    program?.exercises.map((ex) => ({
      exerciseId: ex.exerciseId,
      status: 'not-attempted' as const,
    })) || []
  );
  const [showSkipDialog, setShowSkipDialog] = useState(false);
  const [showAbandonDialog, setShowAbandonDialog] = useState(false);
  const [skipReason, setSkipReason] = useState('');
  const [sessionAbandoned, setSessionAbandoned] = useState(false);

  // Feedback de fin de séance
  const [showFeedbackDialog, setShowFeedbackDialog] = useState(false);
  const [pain, setPain] = useState([3]);
  const [difficulty, setDifficulty] = useState([5]);
  const [comment, setComment] = useState('');

  if (!program) {
    return (
      <div className="max-w-4xl mx-auto p-4">
        <p>Programme introuvable</p>
      </div>
    );
  }

  const currentProgramExercise = program.exercises[currentExerciseIndex];
  const currentExercise = currentProgramExercise
    ? getExerciseById(currentProgramExercise.exerciseId)
    : null;

  const handleComplete = () => {
    const newProgress = [...exerciseProgress];
    newProgress[currentExerciseIndex] = {
      exerciseId: currentProgramExercise.exerciseId,
      status: 'completed',
    };
    setExerciseProgress(newProgress);

    if (currentExerciseIndex < program.exercises.length - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
    } else {
      // Séance terminée
      setShowFeedbackDialog(true);
    }
  };

  const handleSkip = () => {
    const newProgress = [...exerciseProgress];
    newProgress[currentExerciseIndex] = {
      exerciseId: currentProgramExercise.exerciseId,
      status: 'skipped',
      skipReason: skipReason || undefined,
    };
    setExerciseProgress(newProgress);
    setSkipReason('');
    setShowSkipDialog(false);

    if (currentExerciseIndex < program.exercises.length - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
    } else {
      // Séance terminée
      setShowFeedbackDialog(true);
    }
  };

  const handleAbandon = () => {
    setSessionAbandoned(true);
    setShowAbandonDialog(false);
    setShowFeedbackDialog(true);
  };

  const handleSubmitFeedback = () => {
    // Ici on enregistrerait le feedback
    console.log('Feedback:', { pain: pain[0], difficulty: difficulty[0], comment });
    navigate('/patient');
  };

  const completedCount = exerciseProgress.filter((e) => e.status === 'completed').length;
  const progress = ((currentExerciseIndex + 1) / program.exercises.length) * 100;

  return (
    <div className="max-w-4xl mx-auto">
      {/* Session Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Badge variant={program.therapyType}>
              {getTherapyTypeLabel(program.therapyType)}
            </Badge>
            <span className="font-semibold">{program.title}</span>
          </div>
          <button
            onClick={() => setShowAbandonDialog(true)}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Progress Stepper */}
        <div className="flex items-center gap-2">
          {program.exercises.map((ex, index) => (
            <div
              key={ex.exerciseId}
              className={`flex-1 h-1 rounded-full ${
                index < currentExerciseIndex
                  ? 'bg-green-500'
                  : index === currentExerciseIndex
                  ? 'bg-[#00BAA8]'
                  : 'bg-gray-200'
              }`}
            />
          ))}
        </div>
        <div className="text-sm text-gray-600 mt-2">
          Exercice {currentExerciseIndex + 1} sur {program.exercises.length}
        </div>
      </div>

      {/* Exercise Content */}
      {currentExercise && !sessionAbandoned && (
        <div className="p-6 space-y-6">
          {/* Video Placeholder */}
          <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
            <div className="text-center text-white">
              <div className="text-6xl mb-4">🎥</div>
              <p className="text-lg">Vidéo : {currentExercise.title}</p>
              <p className="text-sm text-gray-400 mt-2">{currentExercise.videoUrl}</p>
            </div>
          </div>

          {/* Exercise Details */}
          <div>
            <h2 className="text-2xl mb-2">{currentExercise.title}</h2>
            <p className="text-gray-600 mb-4">{currentExercise.description}</p>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Consignes :</h3>
              <div className="space-y-1 text-sm">
                {currentProgramExercise.sets && currentProgramExercise.reps && (
                  <p>
                    • {currentProgramExercise.sets} séries de{' '}
                    {currentProgramExercise.reps} répétitions
                  </p>
                )}
                {currentProgramExercise.duration && (
                  <p>• Durée : {Math.floor(currentProgramExercise.duration / 60)} minutes</p>
                )}
                {currentProgramExercise.weight && (
                  <p>• Charge : {currentProgramExercise.weight} kg</p>
                )}
              </div>
            </div>
          </div>

          {/* Pain Warning */}
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-orange-900">
              Si la douleur est trop forte, n'hésitez pas à passer cet exercice ou à
              abandonner la séance. Votre bien-être est notre priorité.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-3">
            <Button size="lg" onClick={handleComplete} className="w-full">
              <CheckCircle className="w-5 h-5 mr-2" />
              Exercice terminé - Passer au suivant
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => setShowSkipDialog(true)}
              className="w-full"
            >
              <SkipForward className="w-5 h-5 mr-2" />
              Passer cet exercice
            </Button>
          </div>
        </div>
      )}

      {/* Skip Dialog */}
      <Dialog open={showSkipDialog} onOpenChange={setShowSkipDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Passer cet exercice</DialogTitle>
            <DialogDescription>
              Pourquoi souhaitez-vous passer cet exercice ? (optionnel)
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={skipReason}
            onChange={(e) => setSkipReason(e.target.value)}
            placeholder="Trop de douleur, fatigue, difficulté technique..."
            rows={3}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSkipDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleSkip}>Valider et continuer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Abandon Dialog */}
      <Dialog open={showAbandonDialog} onOpenChange={setShowAbandonDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Abandonner la séance ?</DialogTitle>
            <DialogDescription>
              Vous pourrez reprendre une nouvelle séance plus tard. Les exercices déjà
              réalisés seront comptabilisés.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAbandonDialog(false)}>
              Continuer la séance
            </Button>
            <Button variant="destructive" onClick={handleAbandon}>
              Abandonner
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Feedback Dialog */}
      <Dialog open={showFeedbackDialog} onOpenChange={() => {}}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {sessionAbandoned ? 'Séance abandonnée' : 'Séance terminée !'}
            </DialogTitle>
            <DialogDescription>
              {sessionAbandoned
                ? 'Merci pour votre effort. Prenez soin de vous.'
                : 'Félicitations ! Partagez votre ressenti :'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div>
              <Label>Niveau de douleur : {pain[0]}/10</Label>
              <Slider
                value={pain}
                onValueChange={setPain}
                max={10}
                step={1}
                className="mt-2"
              />
            </div>

            <div>
              <Label>Difficulté : {difficulty[0]}/10</Label>
              <Slider
                value={difficulty}
                onValueChange={setDifficulty}
                max={10}
                step={1}
                className="mt-2"
              />
            </div>

            <div>
              <Label>Commentaire (optionnel)</Label>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Vos remarques sur la séance..."
                className="mt-2"
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button onClick={handleSubmitFeedback} className="w-full">
              Terminer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
