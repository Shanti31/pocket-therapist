import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Trophy, Award, Star, Target, Zap, TrendingUp } from 'lucide-react';
import { getCompletedSessions } from '../../data/mockData';

const PATIENT_ID = 'p-1';

interface BadgeItem {
  id: string;
  icon: React.ElementType;
  title: string;
  description: string;
  achieved: boolean;
  progress?: number;
}

export function Achievements() {
  const completedSessions = getCompletedSessions(PATIENT_ID);
  const totalSessions = completedSessions.length;
  const completeSessions = completedSessions.filter((s) => s.status === 'complete').length;

  const badges: BadgeItem[] = [
    {
      id: 'first-session',
      icon: Star,
      title: 'Première séance',
      description: 'Complétez votre première séance',
      achieved: totalSessions >= 1,
    },
    {
      id: 'five-sessions',
      icon: Award,
      title: '5 séances',
      description: 'Complétez 5 séances',
      achieved: totalSessions >= 5,
      progress: Math.min((totalSessions / 5) * 100, 100),
    },
    {
      id: 'perfectionist',
      icon: Trophy,
      title: 'Perfectionniste',
      description: 'Complétez 3 séances à 100%',
      achieved: completeSessions >= 3,
      progress: Math.min((completeSessions / 3) * 100, 100),
    },
    {
      id: 'consistent',
      icon: Target,
      title: 'Régularité',
      description: 'Complétez des séances 3 jours de suite',
      achieved: false,
      progress: 66,
    },
    {
      id: 'early-bird',
      icon: Zap,
      title: 'Lève-tôt',
      description: 'Complétez une séance avant 9h',
      achieved: true,
    },
    {
      id: 'progression',
      icon: TrendingUp,
      title: 'En progression',
      description: 'Réduisez votre douleur de 30%',
      achieved: false,
      progress: 45,
    },
  ];

  const achievedCount = badges.filter((b) => b.achieved).length;
  const achievementProgress = (achievedCount / badges.length) * 100;

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <div>
        <h2 className="text-2xl mb-2">Mes Succès</h2>
        <p className="text-gray-600">
          Suivez votre progression et débloquez des badges !
        </p>
      </div>

      {/* Overall Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Progression globale</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Badges débloqués</span>
              <span className="text-sm font-semibold text-[#00BAA8]">
                {achievedCount}/{badges.length}
              </span>
            </div>
            <Progress value={achievementProgress} />
          </div>

          <div className="grid grid-cols-3 gap-4 pt-4 border-t">
            <div className="text-center">
              <div className="text-3xl font-bold text-[#00BAA8]">{totalSessions}</div>
              <div className="text-sm text-gray-600">Séances</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#00BAA8]">{completeSessions}</div>
              <div className="text-sm text-gray-600">Complètes</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#00BAA8]">15%</div>
              <div className="text-sm text-gray-600">Top patients</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Badges */}
      <div>
        <h3 className="text-xl mb-4">Badges</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          {badges.map((badge) => {
            const Icon = badge.icon;
            return (
              <Card
                key={badge.id}
                className={`${
                  badge.achieved ? 'bg-gradient-to-br from-yellow-50 to-orange-50' : ''
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                        badge.achieved
                          ? 'bg-[#00BAA8] text-white'
                          : 'bg-gray-200 text-gray-400'
                      }`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold">{badge.title}</h4>
                        {badge.achieved && (
                          <Badge className="bg-yellow-100 text-yellow-800">Obtenu</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{badge.description}</p>
                      {!badge.achieved && badge.progress !== undefined && (
                        <div className="space-y-1">
                          <Progress value={badge.progress} />
                          <div className="text-xs text-gray-500 text-right">
                            {Math.round(badge.progress)}%
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Motivational Message */}
      <Card className="bg-[#00BAA8] text-white">
        <CardContent className="p-6 text-center">
          <Trophy className="w-12 h-12 mx-auto mb-3" />
          <h3 className="text-xl mb-2">Excellent travail !</h3>
          <p className="text-white/90">
            Vous progressez remarquablement bien. Continuez sur cette lancée, chaque
            effort compte dans votre rétablissement.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
