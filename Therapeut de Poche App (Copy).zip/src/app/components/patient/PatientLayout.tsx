import { Outlet, NavLink } from 'react-router';
import { Home, History, Trophy, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/button';
import { useNavigate } from 'react-router';

export function PatientLayout() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-[#00BAA8] text-white p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/')}
            className="text-white hover:bg-[#009B8A]"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl">Thérapeute de Poche</h1>
          <div className="w-10" />
        </div>
      </header>

      {/* Main content */}
      <main className="pb-20">
        <Outlet />
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="max-w-4xl mx-auto flex items-center justify-around">
          <NavLink
            to="/patient"
            end
            className={({ isActive }) =>
              `flex flex-col items-center py-3 px-4 transition-colors ${
                isActive ? 'text-[#00BAA8]' : 'text-gray-600'
              }`
            }
          >
            <Home className="w-6 h-6" />
            <span className="text-xs mt-1">Accueil</span>
          </NavLink>

          <NavLink
            to="/patient/history"
            className={({ isActive }) =>
              `flex flex-col items-center py-3 px-4 transition-colors ${
                isActive ? 'text-[#00BAA8]' : 'text-gray-600'
              }`
            }
          >
            <History className="w-6 h-6" />
            <span className="text-xs mt-1">Historique</span>
          </NavLink>

          <NavLink
            to="/patient/achievements"
            className={({ isActive }) =>
              `flex flex-col items-center py-3 px-4 transition-colors ${
                isActive ? 'text-[#00BAA8]' : 'text-gray-600'
              }`
            }
          >
            <Trophy className="w-6 h-6" />
            <span className="text-xs mt-1">Succès</span>
          </NavLink>
        </div>
      </nav>
    </div>
  );
}
