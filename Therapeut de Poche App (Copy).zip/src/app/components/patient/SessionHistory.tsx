import { useState } from 'react';
import { Badge } from '../ui/badge';
import { Card, CardContent } from '../ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { CheckCircle, SkipForward, Ban } from 'lucide-react';
import {
  getCompletedSessions,
  getProgramById,
  getExerciseById,
  getTherapyTypeLabel,
  getStatusLabel,
} from '../../data/mockData';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { Session, CustomProgram } from '../../types';

const PATIENT_ID = 'p-1';

export function SessionHistory() {
  const [selectedSession, setSelectedSession] = useState<{
    session: Session;
    program: CustomProgram;
  } | null>(null);

  const completedSessions = getCompletedSessions(PATIENT_ID);

  const handleSessionClick = (session: Session) => {
    const program = getProgramById(PATIENT_ID, session.programId);
    if (program) {
      setSelectedSession({ session, program });
    }
  };

  const getCompletionRatio = (session: Session, program: CustomProgram) => {
    const completed = session.exercises.filter((e) => e.status === 'completed').length;
    const total = program.exercises.length;
    return { completed, total };
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

    if (diffInDays === 0) {
      return `Aujourd'hui, ${format(date, 'HH:mm', { locale: fr })}`;
    } else if (diffInDays === 1) {
      return `Hier, ${format(date, 'HH:mm', { locale: fr })}`;
    } else {
      return format(date, "d MMMM 'à' HH:mm", { locale: fr });
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <h2 className="text-2xl">Historique des séances</h2>

      <div className="space-y-3">
        {completedSessions.map((session) => {
          const program = getProgramById(PATIENT_ID, session.programId);
          if (!program) return null;

          const { completed, total } = getCompletionRatio(session, program);
          const percentage = Math.round((completed / total) * 100);

          return (
            <Card
              key={session.id}
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => handleSessionClick(session)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant={program.therapyType}>
                        {getTherapyTypeLabel(program.therapyType)}
                      </Badge>
                      <Badge variant={session.status}>{getStatusLabel(session.status)}</Badge>
                    </div>
                    <div className="font-semibold text-lg mb-1">{program.title}</div>
                    <div className="text-sm text-gray-600">{formatDate(session.date)}</div>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <div className="text-right">
                      <div className="text-2xl font-bold text-[#00BAA8]">{percentage}%</div>
                      <div className="text-xs text-gray-500">
                        {completed}/{total} exercices
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Session Detail Dialog */}
      <Dialog open={!!selectedSession} onOpenChange={() => setSelectedSession(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 flex-wrap">
              {selectedSession && (
                <>
                  <Badge variant={selectedSession.program.therapyType}>
                    {getTherapyTypeLabel(selectedSession.program.therapyType)}
                  </Badge>
                  <Badge variant={selectedSession.session.status}>
                    {getStatusLabel(selectedSession.session.status)}
                  </Badge>
                  <span>{selectedSession.program.title}</span>
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              {selectedSession && formatDate(selectedSession.session.date)}
            </DialogDescription>
          </DialogHeader>

          {selectedSession && (
            <div className="space-y-6">
              {/* Exercises List */}
              <div>
                <h4 className="font-semibold mb-3">Exercices</h4>
                <div className="space-y-2">
                  {selectedSession.program.exercises.map((progEx, index) => {
                    const exercise = getExerciseById(progEx.exerciseId);
                    const exerciseStatus = selectedSession.session.exercises.find(
                      (e) => e.exerciseId === progEx.exerciseId
                    );
                    if (!exercise) return null;

                    const statusConfig = {
                      completed: {
                        icon: CheckCircle,
                        color: 'text-green-600',
                        bg: 'bg-green-50',
                        label: 'Fait',
                      },
                      skipped: {
                        icon: SkipForward,
                        color: 'text-yellow-600',
                        bg: 'bg-yellow-50',
                        label: 'Passé',
                      },
                      'not-attempted': {
                        icon: Ban,
                        color: 'text-gray-400',
                        bg: 'bg-gray-50',
                        label: 'Non tenté',
                      },
                    };

                    const config = exerciseStatus
                      ? statusConfig[exerciseStatus.status]
                      : statusConfig['not-attempted'];
                    const Icon = config.icon;

                    return (
                      <div
                        key={progEx.exerciseId}
                        className={`flex items-start gap-3 p-3 rounded-lg ${config.bg}`}
                      >
                        <Icon className={`w-5 h-5 ${config.color} flex-shrink-0 mt-0.5`} />
                        <div className="flex-1">
                          <div className="font-medium">{exercise.title}</div>
                          <div className="text-sm text-gray-600">
                            {progEx.sets && progEx.reps
                              ? `${progEx.sets} × ${progEx.reps}`
                              : progEx.duration
                              ? `${Math.floor(progEx.duration / 60)} min`
                              : 'Selon consignes'}
                          </div>
                          {exerciseStatus?.skipReason && (
                            <div className="text-sm text-gray-500 mt-1 italic">
                              Raison : {exerciseStatus.skipReason}
                            </div>
                          )}
                        </div>
                        <div className={`text-xs font-semibold ${config.color}`}>
                          {config.label}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Feedback */}
              {selectedSession.session.feedback && (
                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3">Feedback</h4>
                  <div className="grid grid-cols-2 gap-4 mb-3">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Douleur</div>
                      <div className="text-2xl font-bold">
                        {selectedSession.session.feedback.pain}/10
                      </div>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Difficulté</div>
                      <div className="text-2xl font-bold">
                        {selectedSession.session.feedback.difficulty}/10
                      </div>
                    </div>
                  </div>
                  {selectedSession.session.feedback.comment && (
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Commentaire</div>
                      <div className="text-sm">{selectedSession.session.feedback.comment}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
