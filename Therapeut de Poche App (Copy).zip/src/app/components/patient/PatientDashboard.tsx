import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Play } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog';
import {
  getTodaysSessions,
  getProgramById,
  getExerciseById,
  getTherapyTypeLabel,
} from '../../data/mockData';
import type { Session, CustomProgram } from '../../types';

// Hard-coded patient ID (Jean Dupont)
const PATIENT_ID = 'p-1';

export function PatientDashboard() {
  const navigate = useNavigate();
  const [selectedSession, setSelectedSession] = useState<{
    session: Session;
    program: CustomProgram;
  } | null>(null);

  const todaysSessions = getTodaysSessions(PATIENT_ID);

  const handleViewSession = (session: Session) => {
    const program = getProgramById(PATIENT_ID, session.programId);
    if (program) {
      setSelectedSession({ session, program });
    }
  };

  const handleStartSession = () => {
    if (selectedSession) {
      navigate(`/patient/session/${selectedSession.session.programId}`);
      setSelectedSession(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      {/* Welcome Banner */}
      <div className="bg-[#00BAA8] text-white p-6 rounded-lg">
        <h2 className="text-2xl mb-2">Bonjour Jean !</h2>
        <p className="text-white/90">Prêt pour vos exercices du jour ?</p>
      </div>

      {/* Motivation Widget */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-3">
            <p className="text-lg">
              <span className="font-semibold">Félicitations !</span> Vous faites
              partie des <span className="font-semibold text-[#00BAA8]">15%</span> les
              plus actifs des patients.
            </p>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progression de la semaine</span>
                <span className="font-semibold">3/4 jours</span>
              </div>
              <Progress value={75} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Today's Sessions */}
      <div>
        <h3 className="text-xl mb-4">À faire aujourd'hui</h3>
        <div className="space-y-4">
          {todaysSessions.map((session) => {
            const program = getProgramById(PATIENT_ID, session.programId);
            if (!program) return null;

            return (
              <Card key={session.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant={program.therapyType}>
                          {getTherapyTypeLabel(program.therapyType)}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl">{program.title}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      {program.exercises.length} exercices •{' '}
                      {program.frequency.perWeek
                        ? `${program.frequency.perWeek}x/semaine`
                        : `${program.frequency.perDay}x/jour`}
                    </div>
                    <Button onClick={() => handleViewSession(session)}>
                      <Play className="w-4 h-4 mr-2" />
                      Voir la séance
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Session Preview Modal */}
      <Dialog open={!!selectedSession} onOpenChange={() => setSelectedSession(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedSession && (
                <>
                  <Badge variant={selectedSession.program.therapyType}>
                    {getTherapyTypeLabel(selectedSession.program.therapyType)}
                  </Badge>
                  {selectedSession.program.title}
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              Aperçu de la séance avant de commencer
            </DialogDescription>
          </DialogHeader>

          {selectedSession && (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Exercices prévus :</h4>
                <div className="space-y-2">
                  {selectedSession.program.exercises.map((progEx, index) => {
                    const exercise = getExerciseById(progEx.exerciseId);
                    if (!exercise) return null;

                    return (
                      <div
                        key={progEx.exerciseId}
                        className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[#00BAA8] text-white flex items-center justify-center text-sm">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <div className="font-medium">{exercise.title}</div>
                          <div className="text-sm text-gray-600">
                            {progEx.sets && progEx.reps
                              ? `${progEx.sets} séries × ${progEx.reps} répétitions`
                              : progEx.duration
                              ? `${Math.floor(progEx.duration / 60)} minutes`
                              : 'Selon consignes'}
                            {progEx.weight && ` • ${progEx.weight}kg`}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedSession(null)}>
              Annuler
            </Button>
            <Button onClick={handleStartSession}>
              <Play className="w-4 h-4 mr-2" />
              Commencer la séance
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
