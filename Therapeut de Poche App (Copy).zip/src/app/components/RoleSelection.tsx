import { useNavigate } from 'react-router';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Stethoscope, User } from 'lucide-react';

export function RoleSelection() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl mb-2">Thérapeute de Poche</h1>
          <p className="text-gray-600">
            Plateforme de rééducation pour thérapeutes et patients
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-16 h-16 rounded-full bg-[#00BAA8] flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl">Patient</CardTitle>
              <CardDescription>
                Accédez à vos séances de rééducation et suivez votre progression
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => navigate('/patient')}
                className="w-full"
                size="lg"
              >
                Accéder en tant que Patient
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-16 h-16 rounded-full bg-[#00BAA8] flex items-center justify-center">
                <Stethoscope className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl">Thérapeute</CardTitle>
              <CardDescription>
                Gérez vos patients, créez des programmes et suivez leur évolution
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => navigate('/therapist')}
                className="w-full"
                size="lg"
              >
                Accéder en tant que Thérapeute
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
