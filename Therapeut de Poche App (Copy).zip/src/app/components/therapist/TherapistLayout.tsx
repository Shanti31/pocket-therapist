import { Outlet, NavLink, useNavigate } from 'react-router';
import { LayoutDashboard, Users, Library, FileText, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/button';

export function TherapistLayout() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/')}
              className="flex-shrink-0"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="font-semibold">Thérapeute de Poche</h1>
          </div>
          <p className="text-sm text-gray-600">Interface Thérapeute</p>
        </div>

        <nav className="flex-1 p-4">
          <div className="space-y-1">
            <NavLink
              to="/therapist"
              end
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-[#00BAA8] text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`
              }
            >
              <LayoutDashboard className="w-5 h-5" />
              <span>Dashboard</span>
            </NavLink>

            <NavLink
              to="/therapist/patients"
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-[#00BAA8] text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`
              }
            >
              <Users className="w-5 h-5" />
              <span>Patients</span>
            </NavLink>

            <NavLink
              to="/therapist/templates"
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-[#00BAA8] text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`
              }
            >
              <FileText className="w-5 h-5" />
              <span>Templates</span>
            </NavLink>

            <NavLink
              to="/therapist/exercises"
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-[#00BAA8] text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`
              }
            >
              <Library className="w-5 h-5" />
              <span>Exercices</span>
            </NavLink>
          </div>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
