import { useState } from 'react';
import { Link } from 'react-router';
import { Search, UserPlus, Filter, LayoutGrid, List } from 'lucide-react';
import { mockPatients } from '../../data/mockData';
import { TherapyType } from '../../types';

type ViewMode = 'list' | 'grid';

export function PatientsList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<TherapyType | 'all'>('all');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [showAddPatientModal, setShowAddPatientModal] = useState(false);
  const [newPatient, setNewPatient] = useState({
    firstName: '',
    lastName: '',
    age: '',
    email: '',
  });

  const filteredPatients = mockPatients.filter(patient => {
    const matchesSearch =
      patient.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.pathology.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFilter =
      filterType === 'all' ||
      patient.programs.some(p => p.therapyType === filterType);

    return matchesSearch && matchesFilter;
  });

  const handleAddPatient = () => {
    console.log('Nouveau patient:', newPatient);
    setShowAddPatientModal(false);
    setNewPatient({ firstName: '', lastName: '', age: '', email: '' });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Patients</h1>
          <p className="text-gray-500 mt-1">Gérer tous vos patients</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors">
          <UserPlus className="w-5 h-5" />
          Nouveau Patient
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher un patient..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as TherapyType | 'all')}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
            >
              <option value="all">Toutes les thérapies</option>
              <option value="physio">Physiothérapie</option>
              <option value="ergo">Ergothérapie</option>
              <option value="logo">Logopédie</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <LayoutGrid className="w-5 h-5 text-gray-400 cursor-pointer" onClick={() => setViewMode('grid')} />
            <List className="w-5 h-5 text-gray-400 cursor-pointer" onClick={() => setViewMode('list')} />
          </div>
        </div>
      </div>

      {/* Patients Grid */}
      <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 ${viewMode === 'list' ? 'hidden' : ''}`}>
        {filteredPatients.map(patient => {
          const lastSession = patient.sessions.length > 0
            ? patient.sessions.reduce((latest, session) =>
                session.date > latest.date ? session : latest
              )
            : null;

          return (
            <Link
              key={patient.id}
              to={`/therapist/patients/${patient.id}`}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 bg-[#00BAA8] rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {patient.firstName[0]}{patient.lastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 text-lg">
                    {patient.firstName} {patient.lastName}
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">{patient.pathology}</p>
                  
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Programmes actifs</span>
                      <span className="font-medium text-gray-900">{patient.programs.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Séances totales</span>
                      <span className="font-medium text-gray-900">{patient.sessions.length}</span>
                    </div>
                    {lastSession && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Dernière séance</span>
                        <span className="font-medium text-gray-900">
                          {lastSession.date.toLocaleDateString('fr-FR', {
                            day: 'numeric',
                            month: 'short',
                          })}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    {patient.programs.map(program => (
                      <span
                        key={program.id}
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          program.therapyType === 'physio'
                            ? 'bg-blue-100 text-blue-800'
                            : program.therapyType === 'ergo'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-orange-100 text-orange-800'
                        }`}
                      >
                        {program.therapyType === 'physio'
                          ? 'Physiothérapie'
                          : program.therapyType === 'ergo'
                          ? 'Ergothérapie'
                          : 'Logopédie'}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {/* Patients List */}
      <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 ${viewMode === 'grid' ? 'hidden' : ''}`}>
        {filteredPatients.map(patient => {
          const lastSession = patient.sessions.length > 0
            ? patient.sessions.reduce((latest, session) =>
                session.date > latest.date ? session : latest
              )
            : null;

          return (
            <Link
              key={patient.id}
              to={`/therapist/patients/${patient.id}`}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 bg-[#00BAA8] rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {patient.firstName[0]}{patient.lastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 text-lg">
                    {patient.firstName} {patient.lastName}
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">{patient.pathology}</p>
                  
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Programmes actifs</span>
                      <span className="font-medium text-gray-900">{patient.programs.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Séances totales</span>
                      <span className="font-medium text-gray-900">{patient.sessions.length}</span>
                    </div>
                    {lastSession && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Dernière séance</span>
                        <span className="font-medium text-gray-900">
                          {lastSession.date.toLocaleDateString('fr-FR', {
                            day: 'numeric',
                            month: 'short',
                          })}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    {patient.programs.map(program => (
                      <span
                        key={program.id}
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          program.therapyType === 'physio'
                            ? 'bg-blue-100 text-blue-800'
                            : program.therapyType === 'ergo'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-orange-100 text-orange-800'
                        }`}
                      >
                        {program.therapyType === 'physio'
                          ? 'Physiothérapie'
                          : program.therapyType === 'ergo'
                          ? 'Ergothérapie'
                          : 'Logopédie'}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {filteredPatients.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">Aucun patient trouvé</p>
        </div>
      )}
    </div>
  );
}