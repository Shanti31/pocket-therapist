import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { ArrowLeft, Plus, Trash2, Save, GripVertical } from 'lucide-react';
import { mockTemplates, mockExercises } from '../../data/mockData';

export function TemplateEditor() {
  const { templateId } = useParams();
  const isNew = templateId === 'new';
  const template = isNew ? null : mockTemplates.find(t => t.id === templateId);
  const [showExerciseSelector, setShowExerciseSelector] = useState(false);

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          to="/therapist/templates"
          className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour aux templates
        </Link>
        
        <h1 className="text-3xl font-bold text-gray-900">
          {isNew ? 'Nouveau Template' : 'Modifier le Template'}
        </h1>
      </div>

      {/* Form */}
      <div className="space-y-6">
        {/* Basic Info */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Informations générales</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Titre du programme
              </label>
              <input
                type="text"
                defaultValue={template?.title || ''}
                placeholder="Ex: Post-op Hanche"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                rows={3}
                defaultValue={template?.description || ''}
                placeholder="Description du programme..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Type de thérapie
              </label>
              <select
                defaultValue={template?.therapyType || 'physio'}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
              >
                <option value="physio">Physiothérapie</option>
                <option value="ergo">Ergothérapie</option>
                <option value="logo">Logopédie</option>
              </select>
            </div>
          </div>
        </div>

        {/* Exercises */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-900">
              Exercices ({template?.exercises.length || 0})
            </h2>
            <button
              onClick={() => setShowExerciseSelector(true)}
              className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
            >
              <Plus className="w-4 h-4" />
              Ajouter un exercice
            </button>
          </div>

          {template && template.exercises.length > 0 ? (
            <div className="divide-y divide-gray-200">
              {template.exercises
                .sort((a, b) => a.order - b.order)
                .map((programEx, index) => {
                  const exercise = mockExercises.find(e => e.id === programEx.exerciseId);
                  if (!exercise) return null;

                  return (
                    <div key={programEx.exerciseId} className="p-6">
                      <div className="flex items-start gap-4">
                        <button className="p-2 text-gray-400 hover:text-gray-600 cursor-grab">
                          <GripVertical className="w-5 h-5" />
                        </button>
                        <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center font-semibold text-gray-600">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{exercise.title}</h3>
                          <p className="text-sm text-gray-500 mt-1">{exercise.description}</p>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Séries
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.sets || ''}
                                min="0"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Répétitions
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.reps || ''}
                                min="0"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Durée (sec)
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.duration || ''}
                                min="0"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Charge (kg)
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.weight || ''}
                                min="0"
                                step="0.5"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                          </div>
                        </div>
                        <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <div className="p-12 text-center">
              <p className="text-gray-500 mb-4">Aucun exercice ajouté</p>
              <button
                onClick={() => setShowExerciseSelector(true)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
              >
                <Plus className="w-5 h-5" />
                Ajouter des exercices
              </button>
            </div>
          )}
        </div>

        {/* Save Button */}
        <div className="flex justify-end gap-3">
          <Link
            to="/therapist/templates"
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Annuler
          </Link>
          <button className="inline-flex items-center gap-2 px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors">
            <Save className="w-5 h-5" />
            {isNew ? 'Créer le template' : 'Enregistrer'}
          </button>
        </div>
      </div>

      {/* Exercise Selector Modal */}
      {showExerciseSelector && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[80vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Sélectionner des exercices</h2>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mockExercises.map(exercise => (
                  <div
                    key={exercise.id}
                    className="border border-gray-200 rounded-lg p-4 hover:border-[#00BAA8] hover:bg-[#00BAA8]/5 cursor-pointer transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{exercise.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">{exercise.description}</p>
                        <span
                          className={`inline-block mt-2 px-2 py-1 rounded text-xs font-medium ${
                            exercise.therapyType === 'physio'
                              ? 'bg-blue-100 text-blue-800'
                              : exercise.therapyType === 'ergo'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-orange-100 text-orange-800'
                          }`}
                        >
                          {exercise.therapyType === 'physio'
                            ? 'Physiothérapie'
                            : exercise.therapyType === 'ergo'
                            ? 'Ergothérapie'
                            : 'Logopédie'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setShowExerciseSelector(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={() => setShowExerciseSelector(false)}
                className="px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
              >
                Ajouter les exercices sélectionnés
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
