import { useState } from 'react';
import { Plus, Search, Filter, Edit, Play, X } from 'lucide-react';
import { mockExercises } from '../../data/mockData';
import { TherapyType, Exercise } from '../../types';

export function ExercisesLibrary() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<TherapyType | 'all'>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);

  const filteredExercises = mockExercises.filter(exercise => {
    const matchesSearch =
      exercise.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exercise.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFilter = filterType === 'all' || exercise.therapyType === filterType;

    return matchesSearch && matchesFilter;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Bibliothèque d'Exercices</h1>
          <p className="text-gray-500 mt-1">Gérer tous les exercices disponibles</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
        >
          <Plus className="w-5 h-5" />
          Nouvel Exercice
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher un exercice..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as TherapyType | 'all')}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
            >
              <option value="all">Toutes les thérapies</option>
              <option value="physio">Physiothérapie</option>
              <option value="ergo">Ergothérapie</option>
              <option value="logo">Logopédie</option>
            </select>
          </div>
        </div>
      </div>

      {/* Exercise Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExercises.map(exercise => (
          <div
            key={exercise.id}
            onClick={() => setSelectedExercise(exercise)}
            className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
          >
            {/* Video Thumbnail */}
            <div className="aspect-video bg-gray-100 flex items-center justify-center relative">
              <Play className="w-16 h-16 text-gray-400" />
              <div className="absolute top-3 right-3">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    exercise.therapyType === 'physio'
                      ? 'bg-blue-100 text-blue-800'
                      : exercise.therapyType === 'ergo'
                      ? 'bg-purple-100 text-purple-800'
                      : 'bg-orange-100 text-orange-800'
                  }`}
                >
                  {exercise.therapyType === 'physio'
                    ? 'Physiothérapie'
                    : exercise.therapyType === 'ergo'
                    ? 'Ergothérapie'
                    : 'Logopédie'}
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="p-5">
              <h3 className="font-semibold text-gray-900 text-lg mb-2">
                {exercise.title}
              </h3>
              <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                {exercise.description}
              </p>

              {/* Default Values */}
              <div className="space-y-2 mb-4">
                {exercise.defaultSets && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Séries par défaut</span>
                    <span className="font-medium text-gray-900">{exercise.defaultSets}</span>
                  </div>
                )}
                {exercise.defaultReps && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Répétitions par défaut</span>
                    <span className="font-medium text-gray-900">{exercise.defaultReps}</span>
                  </div>
                )}
                {exercise.defaultDuration && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Durée par défaut</span>
                    <span className="font-medium text-gray-900">
                      {Math.floor(exercise.defaultDuration / 60)} min
                    </span>
                  </div>
                )}
                {exercise.defaultWeight && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Charge par défaut</span>
                    <span className="font-medium text-gray-900">{exercise.defaultWeight} kg</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <button className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                <Edit className="w-4 h-4" />
                Modifier
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredExercises.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">Aucun exercice trouvé</p>
        </div>
      )}

      {/* Create Modal (simplified) */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Nouvel Exercice</h2>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Titre de l'exercice
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                  placeholder="Ex: Flexion de hanche"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                  placeholder="Description détaillée de l'exercice..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type de thérapie
                </label>
                <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent">
                  <option value="physio">Physiothérapie</option>
                  <option value="ergo">Ergothérapie</option>
                  <option value="logo">Logopédie</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fichier vidéo
                </label>
                <input
                  type="file"
                  accept="video/*"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                />
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
              >
                Créer l'exercice
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Exercise Detail Modal (Grande Modale) */}
      {selectedExercise && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={() => setSelectedExercise(null)}>
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            {/* Header with close button */}
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-start">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">{selectedExercise.title}</h2>
                <span
                  className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                    selectedExercise.therapyType === 'physio'
                      ? 'bg-blue-100 text-blue-800'
                      : selectedExercise.therapyType === 'ergo'
                      ? 'bg-purple-100 text-purple-800'
                      : 'bg-orange-100 text-orange-800'
                  }`}
                >
                  {selectedExercise.therapyType === 'physio'
                    ? 'Physiothérapie'
                    : selectedExercise.therapyType === 'ergo'
                    ? 'Ergothérapie'
                    : 'Logopédie'}
                </span>
              </div>
              <button
                onClick={() => setSelectedExercise(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-gray-500" />
              </button>
            </div>

            {/* Video Player */}
            <div className="aspect-video bg-gray-900 flex items-center justify-center">
              <Play className="w-32 h-32 text-white/50" />
            </div>

            {/* Content */}
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Description complète</h3>
              <p className="text-gray-700 leading-relaxed mb-6">
                {selectedExercise.description}
              </p>

              {/* Parameters */}
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Paramètres par défaut</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {selectedExercise.defaultSets && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Séries</p>
                    <p className="text-2xl font-bold text-gray-900">{selectedExercise.defaultSets}</p>
                  </div>
                )}
                {selectedExercise.defaultReps && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Répétitions</p>
                    <p className="text-2xl font-bold text-gray-900">{selectedExercise.defaultReps}</p>
                  </div>
                )}
                {selectedExercise.defaultDuration && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Durée</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {Math.floor(selectedExercise.defaultDuration / 60)} min
                    </p>
                  </div>
                )}
                {selectedExercise.defaultWeight && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Charge</p>
                    <p className="text-2xl font-bold text-gray-900">{selectedExercise.defaultWeight} kg</p>
                  </div>
                )}
              </div>
            </div>

            {/* Footer Actions */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-6 flex gap-3">
              <button
                onClick={() => setSelectedExercise(null)}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                Fermer
              </button>
              <button className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-medium">
                <Edit className="w-5 h-5" />
                Modifier l'exercice
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}