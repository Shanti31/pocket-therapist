import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { ArrowLeft, Plus, Trash2, Save } from 'lucide-react';
import { mockPatients, mockExercises } from '../../data/mockData';
import { ProgramExercise } from '../../types';

export function PatientDetail() {
  const { patientId } = useParams();
  const patient = mockPatients.find(p => p.id === patientId);
  
  const [selectedProgramId, setSelectedProgramId] = useState<string>(
    patient?.programs[0]?.id || ''
  );

  if (!patient) {
    return (
      <div className="p-6">
        <p>Patient non trouvé</p>
      </div>
    );
  }

  const selectedProgram = patient.programs.find(p => p.id === selectedProgramId);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link
          to="/therapist/patients"
          className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour aux patients
        </Link>
        
        <div className="flex items-start gap-6">
          <div className="w-20 h-20 bg-[#00BAA8] rounded-full flex items-center justify-center text-white font-bold text-2xl">
            {patient.firstName[0]}{patient.lastName[0]}
          </div>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900">
              {patient.firstName} {patient.lastName}
            </h1>
            <p className="text-lg text-gray-600 mt-1">{patient.pathology}</p>
            <p className="text-sm text-gray-500 mt-2">
              Patient depuis le {patient.createdAt.toLocaleDateString('fr-FR', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
              })}
            </p>
          </div>
        </div>
      </div>

      {/* Programme Selection */}
      {patient.programs.length > 0 && (
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Programme à modifier
          </label>
          <select
            value={selectedProgramId}
            onChange={(e) => setSelectedProgramId(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
          >
            {patient.programs.map(program => (
              <option key={program.id} value={program.id}>
                {program.title} ({program.therapyType === 'physio' ? 'Physiothérapie' : program.therapyType === 'ergo' ? 'Ergothérapie' : 'Logopédie'})
              </option>
            ))}
          </select>
        </div>
      )}

      {selectedProgram ? (
        <div className="space-y-6">
          {/* Programme Info */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              {selectedProgram.title}
            </h2>
            <p className="text-gray-600 mb-4">{selectedProgram.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fréquence par semaine
                </label>
                <input
                  type="number"
                  defaultValue={selectedProgram.frequency.perWeek || 0}
                  min="0"
                  max="7"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fréquence par jour
                </label>
                <input
                  type="number"
                  defaultValue={selectedProgram.frequency.perDay || 0}
                  min="0"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Exercises List */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="font-semibold text-lg text-gray-900">
                Exercices du programme ({selectedProgram.exercises.length})
              </h3>
              <button className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors">
                <Plus className="w-4 h-4" />
                Ajouter un exercice
              </button>
            </div>

            <div className="divide-y divide-gray-200">
              {selectedProgram.exercises
                .sort((a, b) => a.order - b.order)
                .map((programEx, index) => {
                  const exercise = mockExercises.find(e => e.id === programEx.exerciseId);
                  if (!exercise) return null;

                  return (
                    <div key={programEx.exerciseId} className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center font-semibold text-gray-600">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{exercise.title}</h4>
                          <p className="text-sm text-gray-500 mt-1">{exercise.description}</p>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Séries
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.sets || '-'}
                                min="0"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Répétitions
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.reps || '-'}
                                min="0"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Durée (sec)
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.duration || '-'}
                                min="0"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1">
                                Charge (kg)
                              </label>
                              <input
                                type="number"
                                defaultValue={programEx.weight || '-'}
                                min="0"
                                step="0.5"
                                placeholder="-"
                                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                              />
                            </div>
                          </div>
                        </div>
                        <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <button className="inline-flex items-center gap-2 px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors">
              <Save className="w-5 h-5" />
              Enregistrer les modifications
            </button>
          </div>

          {/* Session History */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="font-semibold text-lg text-gray-900">
                Historique des séances ({patient.sessions.length})
              </h3>
            </div>
            <div className="divide-y divide-gray-200">
              {patient.sessions
                .filter(s => s.programId === selectedProgramId)
                .sort((a, b) => b.date.getTime() - a.date.getTime())
                .map(session => {
                  const completed = session.exercises.filter(e => e.status === 'completed').length;
                  const total = session.exercises.length;

                  return (
                    <div key={session.id} className="p-4 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <span className="text-sm font-medium text-gray-900">
                              {session.date.toLocaleDateString('fr-FR', {
                                weekday: 'long',
                                day: 'numeric',
                                month: 'long',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                            <span
                              className={`px-2 py-1 rounded text-xs font-medium ${
                                session.status === 'complete'
                                  ? 'bg-green-100 text-green-800'
                                  : session.status === 'partial'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : session.status === 'abandoned'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {session.status === 'complete'
                                ? 'Complète'
                                : session.status === 'partial'
                                ? 'Partielle'
                                : session.status === 'abandoned'
                                ? 'Abandonnée'
                                : 'En attente'}
                            </span>
                          </div>
                          <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                            <span>Adhésion: {completed}/{total}</span>
                            {session.feedback && (
                              <>
                                <span>Douleur: {session.feedback.pain}/10</span>
                                <span>Difficulté: {session.feedback.difficulty}/10</span>
                              </>
                            )}
                          </div>
                          {session.feedback?.comment && (
                            <p className="text-sm text-gray-500 mt-2 italic">
                              "{session.feedback.comment}"
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <p className="text-gray-500 mb-4">Aucun programme assigné à ce patient</p>
          <button className="inline-flex items-center gap-2 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors">
            <Plus className="w-5 h-5" />
            Créer un programme
          </button>
        </div>
      )}
    </div>
  );
}
