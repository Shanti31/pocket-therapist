import { useState } from 'react';
import { Link } from 'react-router';
import { Plus, Eye, LayoutGrid, List } from 'lucide-react';
import { mockTemplates, mockExercises } from '../../data/mockData';

type ViewMode = 'list' | 'grid';

export function TemplatesLibrary() {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Templates de Programmes</h1>
          <p className="text-gray-500 mt-1">Modèles de programmes d'exercices</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Toggle View Mode */}
          <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${
                viewMode === 'list'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Vue Liste"
            >
              <List className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded ${
                viewMode === 'grid'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Vue Grille"
            >
              <LayoutGrid className="w-5 h-5" />
            </button>
          </div>
          <Link
            to="/therapist/templates/new"
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
          >
            <Plus className="w-5 h-5" />
            Nouveau Template
          </Link>
        </div>
      </div>

      {/* Templates Grid View */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockTemplates.map(template => (
            <div
              key={template.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      template.therapyType === 'physio'
                        ? 'bg-blue-100 text-blue-800'
                        : template.therapyType === 'ergo'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-orange-100 text-orange-800'
                    }`}
                  >
                    {template.therapyType === 'physio'
                      ? 'Physiothérapie'
                      : template.therapyType === 'ergo'
                      ? 'Ergothérapie'
                      : 'Logopédie'}
                  </span>
                </div>

                <h3 className="font-bold text-xl text-gray-900 mb-2">
                  {template.title}
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  {template.description}
                </p>

                <div className="space-y-2 mb-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Exercices</span>
                    <span className="font-medium text-gray-900">
                      {template.exercises.length}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Créé le</span>
                    <span className="font-medium text-gray-900">
                      {template.createdAt.toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </div>
                </div>

                {/* Exercise List Preview */}
                <div className="mb-6">
                  <p className="text-xs font-medium text-gray-500 mb-2">EXERCICES INCLUS</p>
                  <div className="space-y-1">
                    {template.exercises
                      .sort((a, b) => a.order - b.order)
                      .slice(0, 3)
                      .map((programEx) => {
                        const exercise = mockExercises.find(e => e.id === programEx.exerciseId);
                        return exercise ? (
                          <div key={programEx.exerciseId} className="text-sm text-gray-700">
                            {programEx.order}. {exercise.title}
                          </div>
                        ) : null;
                      })}
                    {template.exercises.length > 3 && (
                      <div className="text-sm text-gray-500 italic">
                        +{template.exercises.length - 3} autres...
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <Link
                  to={`/therapist/templates/${template.id}`}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
                >
                  <Eye className="w-4 h-4" />
                  Voir plus
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Templates List View */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Template
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Exercices
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date de création
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {mockTemplates.map(template => (
                <tr key={template.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-semibold text-gray-900">{template.title}</p>
                      <p className="text-sm text-gray-500">{template.description}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        template.therapyType === 'physio'
                          ? 'bg-blue-100 text-blue-800'
                          : template.therapyType === 'ergo'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-orange-100 text-orange-800'
                      }`}
                    >
                      {template.therapyType === 'physio'
                        ? 'Physiothérapie'
                        : template.therapyType === 'ergo'
                        ? 'Ergothérapie'
                        : 'Logopédie'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">
                    {template.exercises.length}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {template.createdAt.toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <Link
                      to={`/therapist/templates/${template.id}`}
                      className="text-[#00BAA8] hover:text-[#008C7E] font-medium text-sm"
                    >
                      Voir plus
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
