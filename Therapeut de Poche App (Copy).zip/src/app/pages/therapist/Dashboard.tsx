import { useState } from 'react';
import { Link } from 'react-router';
import { AlertTriangle, UserPlus, TrendingUp, Activity, LayoutGrid, List } from 'lucide-react';
import { mockPatients, mockAlerts, mockExercises } from '../../data/mockData';

type ViewMode = 'list' | 'grid';

export function TherapistDashboard() {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [showAddPatientModal, setShowAddPatientModal] = useState(false);
  const [newPatient, setNewPatient] = useState({
    firstName: '',
    lastName: '',
    age: '',
    email: '',
  });

  const alerts = mockAlerts.filter(a => !a.acknowledged);
  
  // Calculer les stats pour chaque patient basé sur leur dernière séance
  const patientsWithStats = mockPatients.map(patient => {
    const lastSession = patient.sessions.length > 0 
      ? patient.sessions.reduce((latest, session) => 
          session.date > latest.date ? session : latest
        )
      : null;

    const adherence = lastSession 
      ? {
          completed: lastSession.exercises.filter(e => e.status === 'completed').length,
          total: lastSession.exercises.length,
        }
      : { completed: 0, total: 0 };

    return {
      ...patient,
      lastSession,
      adherence,
    };
  });

  // Trier par activité récente
  const sortedPatients = [...patientsWithStats].sort((a, b) => {
    const dateA = a.lastSession?.date || new Date(0);
    const dateB = b.lastSession?.date || new Date(0);
    return dateB.getTime() - dateA.getTime();
  });

  const handleAddPatient = () => {
    // Ici, vous ajouteriez la logique pour créer un nouveau patient
    console.log('Nouveau patient:', newPatient);
    setShowAddPatientModal(false);
    setNewPatient({ firstName: '', lastName: '', age: '', email: '' });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">Vue d'ensemble de vos patients</p>
        </div>
        <button
          onClick={() => setShowAddPatientModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
        >
          <UserPlus className="w-5 h-5" />
          Nouveau Patient
        </button>
      </div>

      {/* Alertes */}
      {alerts.length > 0 && (
        <div className="mb-6 space-y-3">
          {alerts.map(alert => {
            const patient = mockPatients.find(p => p.id === alert.patientId);
            const session = patient?.sessions.find(s => s.id === alert.sessionId);
            
            return (
              <div
                key={alert.id}
                className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3"
              >
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-red-900">
                    Alerte Douleur: {patient?.firstName} {patient?.lastName}
                  </p>
                  <p className="text-red-700 text-sm mt-1">
                    Douleur de {alert.pain}/10 signalée le{' '}
                    {alert.date.toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                  {session?.feedback?.comment && (
                    <p className="text-red-600 text-sm mt-2 italic">
                      "{session.feedback.comment}"
                    </p>
                  )}
                </div>
                <Link
                  to={`/therapist/patients/${alert.patientId}`}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
                >
                  Adapter le programme
                </Link>
              </div>
            );
          })}
        </div>
      )}

      {/* Toggle View + Liste des patients */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="font-semibold text-lg text-gray-900">Patients Récents</h2>
          
          {/* Toggle View Mode */}
          <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${
                viewMode === 'list'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Vue Liste"
            >
              <List className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded ${
                viewMode === 'grid'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Vue Grille"
            >
              <LayoutGrid className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        {viewMode === 'list' ? (
          // Vue Liste (Tableau)
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Patient
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Pathologie
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Adhésion
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Douleur
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Difficulté
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Dernière séance
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {sortedPatients.map(patient => (
                  <tr key={patient.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#00BAA8] rounded-full flex items-center justify-center text-white font-semibold">
                          {patient.firstName[0]}{patient.lastName[0]}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">
                            {patient.firstName} {patient.lastName}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">
                      {patient.pathology}
                    </td>
                    <td className="px-6 py-4">
                      {patient.lastSession ? (
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[80px]">
                            <div
                              className="bg-[#00BAA8] h-2 rounded-full"
                              style={{
                                width: `${(patient.adherence.completed / patient.adherence.total) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="text-sm text-gray-700 font-medium">
                            {patient.adherence.completed}/{patient.adherence.total}
                          </span>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {patient.lastSession?.feedback ? (
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-semibold ${
                              patient.lastSession.feedback.pain >= 8
                                ? 'text-red-600'
                                : patient.lastSession.feedback.pain >= 5
                                ? 'text-orange-600'
                                : 'text-green-600'
                            }`}
                          >
                            {patient.lastSession.feedback.pain}/10
                          </span>
                          {patient.lastSession.feedback.pain >= 8 && (
                            <AlertTriangle className="w-4 h-4 text-red-600" />
                          )}
                        </div>
                      ) : (
                        <span className="text-sm text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {patient.lastSession?.feedback ? (
                        <span className="text-sm text-gray-700">
                          {patient.lastSession.feedback.difficulty}/10
                        </span>
                      ) : (
                        <span className="text-sm text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {patient.lastSession ? (
                        <>
                          {patient.lastSession.date.toLocaleDateString('fr-FR', {
                            day: 'numeric',
                            month: 'short',
                          })}
                        </>
                      ) : (
                        '-'
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Link
                        to={`/therapist/patients/${patient.id}`}
                        className="text-[#00BAA8] hover:text-[#008C7E] font-medium text-sm"
                      >
                        Voir détails
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          // Vue Grille (Cartes Paysage)
          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {sortedPatients.map(patient => (
                <Link
                  key={patient.id}
                  to={`/therapist/patients/${patient.id}`}
                  className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#00BAA8] rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
                      {patient.firstName[0]}{patient.lastName[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 truncate">
                        {patient.firstName} {patient.lastName}
                      </h3>
                      <p className="text-sm text-gray-500 truncate">{patient.pathology}</p>
                      
                      {patient.lastSession && (
                        <div className="mt-3 space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-600">Adhésion</span>
                            <span className="font-medium text-gray-900">
                              {patient.adherence.completed}/{patient.adherence.total}
                            </span>
                          </div>
                          {patient.lastSession.feedback && (
                            <>
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">Douleur</span>
                                <span
                                  className={`font-semibold ${
                                    patient.lastSession.feedback.pain >= 8
                                      ? 'text-red-600'
                                      : patient.lastSession.feedback.pain >= 5
                                      ? 'text-orange-600'
                                      : 'text-green-600'
                                  }`}
                                >
                                  {patient.lastSession.feedback.pain}/10
                                  {patient.lastSession.feedback.pain >= 8 && ' ⚠️'}
                                </span>
                              </div>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Stats rapides */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Patients</p>
              <p className="text-2xl font-bold text-gray-900">{mockPatients.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Exercices Actifs</p>
              <p className="text-2xl font-bold text-gray-900">{mockExercises.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Alertes en cours</p>
              <p className="text-2xl font-bold text-gray-900">{alerts.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Modale Ajout Patient */}
      {showAddPatientModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Nouveau Patient</h2>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Prénom
                </label>
                <input
                  type="text"
                  value={newPatient.firstName}
                  onChange={(e) => setNewPatient({ ...newPatient, firstName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                  placeholder="Jean"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nom
                </label>
                <input
                  type="text"
                  value={newPatient.lastName}
                  onChange={(e) => setNewPatient({ ...newPatient, lastName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                  placeholder="Dupont"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Âge
                </label>
                <input
                  type="number"
                  value={newPatient.age}
                  onChange={(e) => setNewPatient({ ...newPatient, age: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                  placeholder="65"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={newPatient.email}
                  onChange={(e) => setNewPatient({ ...newPatient, email: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
                  placeholder="jean.dupont@email.com"
                />
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => {
                  setShowAddPatientModal(false);
                  setNewPatient({ firstName: '', lastName: '', age: '', email: '' });
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleAddPatient}
                className="flex-1 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
              >
                Ajouter
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
