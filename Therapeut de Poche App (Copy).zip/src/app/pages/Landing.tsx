import { Link } from 'react-router';
import { UserCog, User } from 'lucide-react';

export function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00BAA8] to-[#008C7E] flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Thérapeute de Poche
          </h1>
          <p className="text-xl text-white/90">
            Plateforme de rééducation pour patients hospitalisés
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Thérapeute Card */}
          <Link
            to="/therapist"
            className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all hover:scale-105"
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="w-20 h-20 bg-[#00BAA8] rounded-full flex items-center justify-center">
                <UserCog className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Thérapeute</h2>
              <p className="text-gray-600">
                Créez des programmes, suivez vos patients et adaptez les exercices
              </p>
            </div>
          </Link>

          {/* Patient Card */}
          <Link
            to="/patient/p1"
            className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all hover:scale-105"
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="w-20 h-20 bg-[#00BAA8] rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Patient</h2>
              <p className="text-gray-600">
                Consultez vos séances, réalisez vos exercices et suivez votre progression
              </p>
            </div>
          </Link>
        </div>

        <p className="text-center text-white/80 mt-8 text-sm">
          Prototype de démonstration - Mars 2026
        </p>
      </div>
    </div>
  );
}
