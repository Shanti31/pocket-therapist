import { useParams } from 'react-router';
import { Trophy, Star, Award, Zap, Target, TrendingUp, Calendar, Heart } from 'lucide-react';
import { mockPatients } from '../../data/mockData';

export function Achievements() {
  const { patientId } = useParams();
  const patient = mockPatients.find(p => p.id === patientId);

  if (!patient) {
    return <div className="p-6">Patient non trouvé</div>;
  }

  const totalSessions = patient.sessions.filter(s => s.status !== 'pending').length;
  const completedSessions = patient.sessions.filter(s => s.status === 'complete').length;

  // Calculer les badges débloqués
  const badges = [
    {
      id: 'first-session',
      icon: Star,
      title: 'Première Séance',
      description: 'Vous avez complété votre première séance',
      unlocked: totalSessions >= 1,
      color: 'bg-yellow-100 text-yellow-600',
      borderColor: 'border-yellow-300',
    },
    {
      id: 'five-sessions',
      icon: Zap,
      title: '5 Séances',
      description: 'Vous avez complété 5 séances',
      unlocked: completedSessions >= 5,
      color: 'bg-orange-100 text-orange-600',
      borderColor: 'border-orange-300',
    },
    {
      id: 'perfect-week',
      icon: Calendar,
      title: 'Semaine Parfaite',
      description: 'Toutes les séances de la semaine complétées',
      unlocked: completedSessions >= 4,
      color: 'bg-green-100 text-green-600',
      borderColor: 'border-green-300',
    },
    {
      id: 'perseverance',
      icon: Target,
      title: 'Persévérance',
      description: 'Vous avez fait 3 séances cette semaine',
      unlocked: totalSessions >= 3,
      color: 'bg-blue-100 text-blue-600',
      borderColor: 'border-blue-300',
    },
    {
      id: 'ten-sessions',
      icon: Trophy,
      title: '10 Séances',
      description: 'Vous avez complété 10 séances',
      unlocked: completedSessions >= 10,
      color: 'bg-purple-100 text-purple-600',
      borderColor: 'border-purple-300',
    },
    {
      id: 'warrior',
      icon: Award,
      title: 'Guerrier',
      description: 'Vous avez poursuivi malgré la difficulté',
      unlocked: totalSessions >= 5,
      color: 'bg-red-100 text-red-600',
      borderColor: 'border-red-300',
    },
    {
      id: 'progress',
      icon: TrendingUp,
      title: 'En Progression',
      description: 'Votre douleur diminue au fil du temps',
      unlocked: totalSessions >= 3,
      color: 'bg-teal-100 text-teal-600',
      borderColor: 'border-teal-300',
    },
    {
      id: 'dedication',
      icon: Heart,
      title: 'Dévouement',
      description: 'Vous êtes parmi les 15% les plus actifs',
      unlocked: completedSessions >= 3,
      color: 'bg-pink-100 text-pink-600',
      borderColor: 'border-pink-300',
    },
  ];

  const unlockedBadges = badges.filter(b => b.unlocked);
  const lockedBadges = badges.filter(b => !b.unlocked);

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-6 md:ml-64">
      {/* Header */}
      <div className="bg-[#00BAA8] text-white px-6 py-8">
        <h1 className="text-3xl font-bold">Mes Succès</h1>
        <p className="text-white/90 mt-2 text-lg">Célébrez vos accomplissements</p>
      </div>

      <div className="max-w-6xl mx-auto px-4 -mt-6">
        {/* Stats */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-[#00BAA8] rounded-full mb-4">
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              {unlockedBadges.length}/{badges.length} Badges
            </h2>
            <p className="text-gray-600">Vous avez débloqué {unlockedBadges.length} badges</p>
          </div>

          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-[#00BAA8] h-3 rounded-full transition-all duration-500"
              style={{ width: `${(unlockedBadges.length / badges.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Encouragement Message */}
        <div className="bg-gradient-to-br from-[#00BAA8] to-[#008C7E] text-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-start gap-4">
            <Star className="w-8 h-8 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-xl font-bold mb-2">Excellent travail {patient.firstName} !</h3>
              <p className="text-white/90">
                Vous faites des progrès remarquables. Continuez à vous dépasser, chaque séance vous rapproche
                de vos objectifs de rééducation.
              </p>
            </div>
          </div>
        </div>

        {/* Unlocked Badges */}
        {unlockedBadges.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Badges débloqués</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {unlockedBadges.map(badge => {
                const Icon = badge.icon;
                return (
                  <div
                    key={badge.id}
                    className={`bg-white rounded-xl shadow-sm border-2 ${badge.borderColor} p-6 transform hover:scale-105 transition-transform`}
                  >
                    <div className={`w-16 h-16 rounded-full ${badge.color} flex items-center justify-center mb-4`}>
                      <Icon className="w-8 h-8" />
                    </div>
                    <h3 className="font-bold text-lg text-gray-900 mb-2">{badge.title}</h3>
                    <p className="text-sm text-gray-600">{badge.description}</p>
                    <div className="mt-4">
                      <span className="inline-block px-3 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                        ✓ Débloqué
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Locked Badges */}
        {lockedBadges.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Badges à débloquer</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {lockedBadges.map(badge => {
                const Icon = badge.icon;
                return (
                  <div
                    key={badge.id}
                    className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 opacity-60"
                  >
                    <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                      <Icon className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="font-bold text-lg text-gray-700 mb-2">{badge.title}</h3>
                    <p className="text-sm text-gray-500">{badge.description}</p>
                    <div className="mt-4">
                      <span className="inline-block px-3 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded-full">
                        🔒 Verrouillé
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Motivational Footer */}
        <div className="mt-8 bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
          <h3 className="text-xl font-bold text-gray-900 mb-2">Continuez comme ça !</h3>
          <p className="text-gray-600">
            Chaque séance complétée est une victoire. Vous êtes sur la bonne voie pour atteindre vos objectifs.
          </p>
        </div>
      </div>
    </div>
  );
}
