import { useState } from 'react';
import { Link, useParams } from 'react-router';
import { Play, Calendar, CheckCircle, XCircle, MinusCircle, ChevronRight, Clock, MessageSquare } from 'lucide-react';
import { mockPatients, mockExercises } from '../../data/mockData';
import { Session, CustomProgram } from '../../types';

export function PatientDashboard() {
  const { patientId } = useParams();
  const patient = mockPatients.find(p => p.id === patientId);
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [notes, setNotes] = useState('');

  if (!patient) {
    return <div className="p-6">Patient non trouvé</div>;
  }

  // Calculer les séances complétées cette semaine
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  const sessionsThisWeek = patient.sessions.filter(
    s => s.date >= startOfWeek && s.status !== 'pending'
  );

  // Pour la démo, on considère que chaque programme a 4 séances par semaine
  const totalSessionsExpected = patient.programs.reduce(
    (sum, p) => sum + (p.frequency.perWeek || 0),
    0
  );
  const completionRate = totalSessionsExpected > 0
    ? Math.round((sessionsThisWeek.length / totalSessionsExpected) * 100)
    : 0;

  // Séances triées par date (les plus récentes en premier)
  const completedSessions = patient.sessions
    .filter(s => s.status !== 'pending')
    .sort((a, b) => b.date.getTime() - a.date.getTime());

  const getTherapyLabel = (type: string) => {
    switch (type) {
      case 'physio':
        return 'Physiothérapie';
      case 'ergo':
        return 'Ergothérapie';
      case 'logo':
        return 'Logopédie';
      default:
        return type;
    }
  };

  const getTherapyColor = (type: string) => {
    switch (type) {
      case 'physio':
        return 'bg-blue-100 text-blue-800';
      case 'ergo':
        return 'bg-purple-100 text-purple-800';
      case 'logo':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'complete':
        return { label: 'Complète', color: 'bg-green-100 text-green-800', icon: CheckCircle };
      case 'partial':
        return { label: 'Partielle', color: 'bg-yellow-100 text-yellow-800', icon: MinusCircle };
      case 'abandoned':
        return { label: 'Abandonnée', color: 'bg-red-100 text-red-800', icon: XCircle };
      default:
        return { label: 'En attente', color: 'bg-gray-100 text-gray-800', icon: Calendar };
    }
  };

  // Calculer la durée estimée d'un programme
  const calculateProgramDuration = (program: CustomProgram) => {
    let totalMinutes = 0;
    program.exercises.forEach(programEx => {
      if (programEx.duration) {
        totalMinutes += programEx.duration / 60;
      } else {
        // Estimation : 30 secondes par répétition
        const reps = (programEx.sets || 1) * (programEx.reps || 1);
        totalMinutes += (reps * 30) / 60;
      }
    });
    return Math.ceil(totalMinutes);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-6 md:ml-64">
      {/* Header Banner */}
      <div className="bg-[#00BAA8] text-white px-6 py-8">
        <h1 className="text-3xl font-bold">Bonjour {patient.firstName} !</h1>
        <p className="text-white/90 mt-2 text-lg">Prêt pour votre séance d'aujourd'hui ?</p>
      </div>

      <div className="max-w-4xl mx-auto px-4 -mt-6">
        {/* Motivation Widget */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex items-start gap-4">
            <div className="flex-1">
              <p className="text-lg font-semibold text-gray-900 mb-2">
                Félicitations ! 🎉
              </p>
              <p className="text-gray-700">
                Vous faites partie des <span className="font-bold text-[#00BAA8]">15% les plus actifs</span> des patients.
                Continuez comme ça !
              </p>
              {/* Progress bar for the week */}
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Progression cette semaine</span>
                  <span className="font-semibold text-[#00BAA8]">{completionRate}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-[#00BAA8] h-3 rounded-full transition-all duration-500"
                    style={{ width: `${completionRate}%` }}
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  {sessionsThisWeek.length} séance{sessionsThisWeek.length > 1 ? 's' : ''} réalisée{sessionsThisWeek.length > 1 ? 's' : ''} sur {totalSessionsExpected} prévues
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Séances du jour */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">À faire aujourd'hui</h2>
          <div className="space-y-4">
            {patient.programs.map(program => (
              <SessionCard key={program.id} program={program} patientId={patient.id} />
            ))}
          </div>
        </div>

        {/* Séances terminées */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Séances terminées</h2>
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            {completedSessions.length > 0 ? (
              <div className="divide-y divide-gray-200">
                {completedSessions.map(session => {
                  const program = patient.programs.find(p => p.id === session.programId);
                  if (!program) return null;

                  const completed = session.exercises.filter(e => e.status === 'completed').length;
                  const total = session.exercises.length;
                  const statusBadge = getStatusBadge(session.status);
                  const StatusIcon = statusBadge.icon;

                  return (
                    <button
                      key={session.id}
                      onClick={() => setSelectedSession(session)}
                      className="w-full p-4 hover:bg-gray-50 transition-colors text-left"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap mb-2">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${getTherapyColor(program.therapyType)}`}>
                              {getTherapyLabel(program.therapyType)}
                            </span>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusBadge.color} flex items-center gap-1`}>
                              <StatusIcon className="w-3 h-3" />
                              {statusBadge.label}
                            </span>
                          </div>
                          <h3 className="font-semibold text-gray-900 mb-1">{program.title}</h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <span>
                              {session.date.toLocaleDateString('fr-FR', {
                                weekday: 'long',
                                day: 'numeric',
                                month: 'long',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                          {/* Visual adherence indicator */}
                          <div className="flex items-center gap-2 mt-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[200px]">
                              <div
                                className={`h-2 rounded-full ${
                                  session.status === 'complete'
                                    ? 'bg-green-500'
                                    : session.status === 'partial'
                                    ? 'bg-yellow-500'
                                    : 'bg-red-500'
                                }`}
                                style={{ width: `${(completed / total) * 100}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium text-gray-700">
                              {completed}/{total} exercices
                            </span>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-400" />
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-12 text-center">
                <p className="text-gray-500">Aucune séance terminée pour le moment</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Session Detail Modal */}
      {selectedSession && (
        <SessionDetailModal
          session={selectedSession}
          patient={patient}
          onClose={() => setSelectedSession(null)}
        />
      )}

      {/* Notes Modal */}
      {showNotesModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900">Mes Notes</h2>
              <p className="text-gray-600 mt-2">Une question, une remarque ? Notez-la ici pour en parler lors de votre prochaine visite avec votre thérapeute.</p>
            </div>
            <div className="p-6">
              <textarea
                className="w-full h-40 p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8]"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Entrez vos notes ici..."
              />
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => setShowNotesModal(false)}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                Annuler
              </button>
              <button
                onClick={() => {
                  // Ici, vous pouvez ajouter la logique pour sauvegarder les notes
                  setShowNotesModal(false);
                }}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-medium"
              >
                <MessageSquare className="w-5 h-5" />
                Sauvegarder les notes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Notes Button */}
      <button
        onClick={() => setShowNotesModal(true)}
        className="fixed bottom-24 right-6 md:bottom-6 md:right-6 w-14 h-14 bg-[#00BAA8] text-white rounded-full shadow-lg hover:bg-[#008C7E] transition-colors flex items-center justify-center z-40"
        title="Mes Notes"
      >
        <MessageSquare className="w-6 h-6" />
      </button>
    </div>
  );
}

// Session Card Component
function SessionCard({ program, patientId }: { program: CustomProgram; patientId: string }) {
  const [showPreview, setShowPreview] = useState(false);

  const getTherapyLabel = (type: string) => {
    switch (type) {
      case 'physio':
        return 'Physiothérapie';
      case 'ergo':
        return 'Ergothérapie';
      case 'logo':
        return 'Logopédie';
      default:
        return type;
    }
  };

  const getTherapyColor = (type: string) => {
    switch (type) {
      case 'physio':
        return 'bg-blue-100 text-blue-800';
      case 'ergo':
        return 'bg-purple-100 text-purple-800';
      case 'logo':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Calculer la durée estimée
  const calculateDuration = () => {
    let totalMinutes = 0;
    program.exercises.forEach(programEx => {
      if (programEx.duration) {
        totalMinutes += programEx.duration / 60;
      } else {
        // Estimation : 30 secondes par répétition
        const reps = (programEx.sets || 1) * (programEx.reps || 1);
        totalMinutes += (reps * 30) / 60;
      }
    });
    return Math.ceil(totalMinutes);
  };

  const estimatedDuration = calculateDuration();

  return (
    <>
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${getTherapyColor(program.therapyType)}`}>
              {getTherapyLabel(program.therapyType)}
            </span>
            <span className="px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-700 flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              {estimatedDuration} min
            </span>
          </div>
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-2">{program.title}</h3>
        <p className="text-gray-600 mb-4">{program.description}</p>
        <div className="flex items-center gap-3 text-sm text-gray-600 mb-6">
          <span>{program.exercises.length} exercices</span>
          <span>•</span>
          <span>{program.frequency.perWeek} fois/semaine</span>
        </div>
        <button
          onClick={() => setShowPreview(true)}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-medium text-lg"
        >
          <Play className="w-5 h-5" />
          Voir la séance
        </button>
      </div>

      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center gap-2 mb-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getTherapyColor(program.therapyType)}`}>
                  {getTherapyLabel(program.therapyType)}
                </span>
              </div>
              <h2 className="text-2xl font-bold text-gray-900">{program.title}</h2>
              <p className="text-gray-600 mt-2">{program.description}</p>
            </div>
            <div className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4">
                Exercices de la séance ({program.exercises.length})
              </h3>
              <div className="space-y-3">
                {program.exercises
                  .sort((a, b) => a.order - b.order)
                  .map((programEx, index) => {
                    const exercise = mockExercises.find(e => e.id === programEx.exerciseId);
                    if (!exercise) return null;

                    return (
                      <div key={programEx.exerciseId} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex gap-3">
                          <div className="w-8 h-8 bg-[#00BAA8] text-white rounded-full flex items-center justify-center font-semibold text-sm">
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-900">{exercise.title}</h4>
                            <p className="text-sm text-gray-600 mt-1">{exercise.description}</p>
                            <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                              {programEx.sets && programEx.reps && (
                                <span>{programEx.sets} × {programEx.reps} répétitions</span>
                              )}
                              {programEx.duration && (
                                <span>{Math.floor(programEx.duration / 60)} min</span>
                              )}
                              {programEx.weight && (
                                <span>{programEx.weight} kg</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => setShowPreview(false)}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                Annuler
              </button>
              <Link
                to={`/patient/${patientId}/session/${program.id}`}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-medium"
              >
                <Play className="w-5 h-5" />
                Commencer la séance
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// Session Detail Modal Component
function SessionDetailModal({
  session,
  patient,
  onClose,
}: {
  session: Session;
  patient: typeof mockPatients[0];
  onClose: () => void;
}) {
  const program = patient.programs.find(p => p.id === session.programId);
  if (!program) return null;

  const getTherapyLabel = (type: string) => {
    switch (type) {
      case 'physio':
        return 'Physiothérapie';
      case 'ergo':
        return 'Ergothérapie';
      case 'logo':
        return 'Logopédie';
      default:
        return type;
    }
  };

  const getTherapyColor = (type: string) => {
    switch (type) {
      case 'physio':
        return 'bg-blue-100 text-blue-800';
      case 'ergo':
        return 'bg-purple-100 text-purple-800';
      case 'logo':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'complete':
        return { label: 'Complète', color: 'bg-green-100 text-green-800' };
      case 'partial':
        return { label: 'Partielle', color: 'bg-yellow-100 text-yellow-800' };
      case 'abandoned':
        return { label: 'Abandonnée', color: 'bg-red-100 text-red-800' };
      default:
        return { label: 'En attente', color: 'bg-gray-100 text-gray-800' };
    }
  };

  const statusBadge = getStatusBadge(session.status);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-2 mb-3">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${getTherapyColor(program.therapyType)}`}>
              {getTherapyLabel(program.therapyType)}
            </span>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusBadge.color}`}>
              {statusBadge.label}
            </span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{program.title}</h2>
          <p className="text-gray-600">
            {session.date.toLocaleDateString('fr-FR', {
              weekday: 'long',
              day: 'numeric',
              month: 'long',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
        </div>

        <div className="p-6">
          {/* Feedback */}
          {session.feedback && (
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Votre feedback</h3>
              <div className="grid grid-cols-2 gap-4 mb-3">
                <div>
                  <span className="text-sm text-gray-600">Douleur</span>
                  <p className="text-2xl font-bold text-gray-900">{session.feedback.pain}/10</p>
                </div>
                <div>
                  <span className="text-sm text-gray-600">Difficulté</span>
                  <p className="text-2xl font-bold text-gray-900">{session.feedback.difficulty}/10</p>
                </div>
              </div>
              {session.feedback.comment && (
                <p className="text-sm text-gray-700 italic">"{session.feedback.comment}"</p>
              )}
            </div>
          )}

          {/* Exercises */}
          <h3 className="font-semibold text-gray-900 mb-4">Exercices</h3>
          <div className="space-y-3">
            {session.exercises.map((sessionEx) => {
              const programEx = program.exercises.find(e => e.exerciseId === sessionEx.exerciseId);
              const exercise = mockExercises.find(e => e.id === sessionEx.exerciseId);
              if (!exercise || !programEx) return null;

              return (
                <div
                  key={sessionEx.exerciseId}
                  className={`border rounded-lg p-4 ${
                    sessionEx.status === 'not-attempted' ? 'opacity-50 bg-gray-50' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      {sessionEx.status === 'completed' && (
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      )}
                      {sessionEx.status === 'skipped' && (
                        <MinusCircle className="w-6 h-6 text-yellow-600" />
                      )}
                      {sessionEx.status === 'not-attempted' && (
                        <XCircle className="w-6 h-6 text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{exercise.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        {sessionEx.status === 'completed' && 'Exercice complété'}
                        {sessionEx.status === 'skipped' && 'Exercice passé'}
                        {sessionEx.status === 'not-attempted' && 'Non tenté (séance abandonnée)'}
                      </p>
                      {sessionEx.skipReason && (
                        <p className="text-sm text-gray-500 mt-2 italic">
                          Raison: {sessionEx.skipReason}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="p-6 border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-medium"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
}