import { useState } from 'react';
import { useParams } from 'react-router';
import { TrendingUp, TrendingDown, Activity, Calendar } from 'lucide-react';
import { mockPatients } from '../../data/mockData';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

type ProgramTab = 'active' | 'history';

export function Progress() {
  const { patientId } = useParams();
  const patient = mockPatients.find(p => p.id === patientId);
  const [programTab, setProgramTab] = useState<ProgramTab>('active');

  if (!patient) {
    return <div className="p-6">Patient non trouvé</div>;
  }

  // Préparer les données pour les graphiques Avant/Après
  const painData = patient.sessions
    .filter(s => s.feedback)
    .sort((a, b) => a.date.getTime() - b.date.getTime())
    .map((session, index) => ({
      date: session.date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }),
      timestamp: session.date.getTime(),
      // Simuler une douleur "avant" (pour la démo, on suppose qu'elle était légèrement plus haute)
      avant: Math.min(10, (session.feedback?.pain || 0) + Math.floor(Math.random() * 2)),
      après: session.feedback?.pain || 0,
    }));

  // Calculer les stats
  const totalSessions = patient.sessions.filter(s => s.status !== 'pending').length;
  const completedSessions = patient.sessions.filter(s => s.status === 'complete').length;
  const avgPain = painData.length > 0
    ? Math.round(painData.reduce((sum, d) => sum + d.après, 0) / painData.length * 10) / 10
    : 0;

  // Calculer la tendance (derniers 3 vs 3 précédents)
  const recentPain = painData.slice(-3).reduce((sum, d) => sum + d.après, 0) / 3;
  const previousPain = painData.slice(-6, -3).reduce((sum, d) => sum + d.après, 0) / 3;
  const painTrend = recentPain < previousPain;

  // Générer le heatmap des 4 dernières semaines
  const generateHeatmapData = () => {
    const weeks = [];
    const today = new Date();
    
    for (let weekIndex = 3; weekIndex >= 0; weekIndex--) {
      const week = [];
      for (let dayIndex = 0; dayIndex < 7; dayIndex++) {
        const date = new Date(today);
        date.setDate(today.getDate() - (weekIndex * 7 + (6 - dayIndex)));
        
        // Vérifier si une séance a été faite ce jour
        const hasSession = patient.sessions.some(session => {
          const sessionDate = new Date(session.date);
          return sessionDate.toDateString() === date.toDateString() && session.status !== 'pending';
        });
        
        week.push({
          date: date,
          hasSession,
          day: dayIndex,
          weekLabel: weekIndex === 0 ? 'Cette semaine' : weekIndex === 1 ? 'Semaine dernière' : `Il y a ${weekIndex} semaines`
        });
      }
      weeks.push(week);
    }
    return weeks;
  };

  const heatmapData = generateHeatmapData();
  const dayLabels = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-6 md:ml-64">
      {/* Header */}
      <div className="bg-[#00BAA8] text-white px-6 py-8">
        <h1 className="text-3xl font-bold">Ma Progression</h1>
        <p className="text-white/90 mt-2 text-lg">Suivez votre évolution au fil du temps</p>
      </div>

      <div className="max-w-6xl mx-auto px-4 -mt-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-5 h-5 text-[#00BAA8]" />
              <span className="text-sm text-gray-600">Séances</span>
            </div>
            <p className="text-3xl font-bold text-gray-900">{totalSessions}</p>
            <p className="text-xs text-gray-500 mt-1">{completedSessions} complètes</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-5 h-5 text-[#00BAA8]" />
              <span className="text-sm text-gray-600">Adhésion</span>
            </div>
            <p className="text-3xl font-bold text-gray-900">
              {Math.round((completedSessions / totalSessions) * 100) || 0}%
            </p>
            <p className="text-xs text-gray-500 mt-1">Taux de complétion</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              {painTrend ? (
                <TrendingDown className="w-5 h-5 text-green-600" />
              ) : (
                <TrendingUp className="w-5 h-5 text-orange-600" />
              )}
              <span className="text-sm text-gray-600">Douleur moy.</span>
            </div>
            <p className="text-3xl font-bold text-gray-900">{avgPain}/10</p>
            <p className="text-xs text-gray-500 mt-1">
              {painTrend ? 'En baisse ↓' : 'Stable'}
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-5 h-5 text-[#00BAA8]" />
              <span className="text-sm text-gray-600">Programmes</span>
            </div>
            <p className="text-3xl font-bold text-gray-900">{patient.programs.length}</p>
            <p className="text-xs text-gray-500 mt-1">Actifs</p>
          </div>
        </div>

        {/* Mes Programmes Section with Tabs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="font-bold text-lg text-gray-900 mb-4">Mes Programmes</h2>
            
            {/* Tabs */}
            <div className="flex gap-2 bg-gray-100 p-1 rounded-lg inline-flex">
              <button
                onClick={() => setProgramTab('active')}
                className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
                  programTab === 'active'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Programmes Actifs
              </button>
              <button
                onClick={() => setProgramTab('history')}
                className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
                  programTab === 'history'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Historique Programmes
              </button>
            </div>
          </div>

          <div className="p-6">
            {programTab === 'active' ? (
              <div className="space-y-4">
                {patient.programs.map(program => {
                  const programSessions = patient.sessions.filter(s => s.programId === program.id);
                  const completed = programSessions.filter(s => s.status === 'complete').length;

                  return (
                    <div key={program.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-gray-900">{program.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{program.description}</p>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            program.therapyType === 'physio'
                              ? 'bg-blue-100 text-blue-800'
                              : program.therapyType === 'ergo'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-orange-100 text-orange-800'
                          }`}
                        >
                          {program.therapyType === 'physio'
                            ? 'Physiothérapie'
                            : program.therapyType === 'ergo'
                            ? 'Ergothérapie'
                            : 'Logopédie'}
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <p className="text-2xl font-bold text-gray-900">{programSessions.length}</p>
                          <p className="text-xs text-gray-500">Séances</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-green-600">{completed}</p>
                          <p className="text-xs text-gray-500">Complètes</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-gray-900">{program.exercises.length}</p>
                          <p className="text-xs text-gray-500">Exercices</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">Aucun programme archivé pour le moment</p>
              </div>
            )}
          </div>
        </div>

        {/* Évolution de la Douleur (Avant vs Après) */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <h2 className="font-bold text-lg text-gray-900 mb-4">Évolution de la Douleur (Avant vs Après séance)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={painData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis domain={[0, 10]} tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="avant"
                stroke="#f59e0b"
                strokeWidth={2}
                dot={{ fill: '#f59e0b', r: 4 }}
                name="Douleur Avant"
              />
              <Line
                type="monotone"
                dataKey="après"
                stroke="#10b981"
                strokeWidth={2}
                dot={{ fill: '#10b981', r: 4 }}
                name="Douleur Après"
              />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-orange-500"></div>
              <span className="text-sm text-gray-600">Avant séance</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-green-500"></div>
              <span className="text-sm text-gray-600">Après séance</span>
            </div>
          </div>
        </div>

        {/* Heatmap Assiduité (4 semaines) */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="font-bold text-lg text-gray-900 mb-4">Assiduité - 4 Dernières Semaines</h2>
          
          <div className="space-y-3">
            {heatmapData.map((week, weekIndex) => (
              <div key={weekIndex}>
                <p className="text-xs text-gray-500 mb-2">{week[0].weekLabel}</p>
                <div className="flex gap-2">
                  {week.map((day, dayIndex) => (
                    <div key={dayIndex} className="flex-1">
                      <div
                        className={`aspect-square rounded-lg flex items-center justify-center text-xs font-medium transition-colors ${
                          day.hasSession
                            ? 'bg-green-500 text-white'
                            : 'bg-gray-100 text-gray-400'
                        }`}
                        title={day.date.toLocaleDateString('fr-FR')}
                      >
                        {dayLabels[dayIndex]}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-4 mt-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-green-500"></div>
              <span className="text-gray-600">Séance effectuée</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-gray-100"></div>
              <span className="text-gray-600">Repos</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
