import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, Play, SkipForward, AlertCircle, Info, ChevronDown, ChevronUp } from 'lucide-react';
import { mockPatients, mockExercises } from '../../data/mockData';
import { ExerciseStatus } from '../../types';

// Émojis pour les niveaux de douleur
const painEmojis = ['😊', '🙂', '😐', '😕', '😣', '😖', '😫', '😩', '😰', '😭', '😱'];

export function SessionPlayer() {
  const { patientId, programId } = useParams();
  const navigate = useNavigate();
  const patient = mockPatients.find(p => p.id === patientId);
  const program = patient?.programs.find(p => p.id === programId);

  // States
  const [showPreSessionPain, setShowPreSessionPain] = useState(true);
  const [preSessionPain, setPreSessionPain] = useState(5);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [exerciseStatuses, setExerciseStatuses] = useState<
    { exerciseId: string; status: ExerciseStatus; skipReason?: string }[]
  >(
    program?.exercises.map(e => ({ exerciseId: e.exerciseId, status: 'completed' as ExerciseStatus })) || []
  );
  const [showSkipModal, setShowSkipModal] = useState(false);
  const [showAbandonModal, setShowAbandonModal] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [showProgressDetails, setShowProgressDetails] = useState(false);
  const [skipReason, setSkipReason] = useState('');
  const [isSessionAbandoned, setIsSessionAbandoned] = useState(false);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);

  // Timer pour les exercices chronométrés
  useEffect(() => {
    if (isTimerRunning && timeRemaining > 0) {
      const interval = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isTimerRunning, timeRemaining]);

  if (!patient || !program) {
    return <div className="p-6">Programme non trouvé</div>;
  }

  const sortedExercises = [...program.exercises].sort((a, b) => a.order - b.order);
  const currentProgramEx = sortedExercises[currentExerciseIndex];
  const currentExercise = mockExercises.find(e => e.id === currentProgramEx?.exerciseId);
  const totalExercises = sortedExercises.length;
  const isLastExercise = currentExerciseIndex === totalExercises - 1;

  const handleNext = () => {
    if (isLastExercise) {
      setShowFeedbackModal(true);
    } else {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
      setIsTimerRunning(false);
      setTimeRemaining(0);
    }
  };

  const handleSkip = () => {
    setShowSkipModal(true);
  };

  const confirmSkip = () => {
    const newStatuses = [...exerciseStatuses];
    newStatuses[currentExerciseIndex] = {
      exerciseId: currentProgramEx.exerciseId,
      status: 'skipped',
      skipReason: skipReason || undefined,
    };
    setExerciseStatuses(newStatuses);
    setSkipReason('');
    setShowSkipModal(false);

    if (isLastExercise) {
      setShowFeedbackModal(true);
    } else {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
      setIsTimerRunning(false);
      setTimeRemaining(0);
    }
  };

  const handleAbandon = () => {
    setShowAbandonModal(true);
  };

  const confirmAbandon = () => {
    const newStatuses = [...exerciseStatuses];
    for (let i = currentExerciseIndex; i < newStatuses.length; i++) {
      newStatuses[i] = {
        exerciseId: sortedExercises[i].exerciseId,
        status: 'not-attempted',
      };
    }
    setExerciseStatuses(newStatuses);
    setIsSessionAbandoned(true);
    setShowAbandonModal(false);
    setShowFeedbackModal(true);
  };

  const startPreSession = () => {
    setShowPreSessionPain(false);
  };

  const startTimer = () => {
    if (currentProgramEx.duration) {
      setTimeRemaining(currentProgramEx.duration);
      setIsTimerRunning(true);
    }
  };

  const getTherapyLabel = (type: string) => {
    switch (type) {
      case 'physio':
        return 'Physiothérapie';
      case 'ergo':
        return 'Ergothérapie';
      case 'logo':
        return 'Logopédie';
      default:
        return type;
    }
  };

  const getTherapyColor = (type: string) => {
    switch (type) {
      case 'physio':
        return 'bg-blue-100 text-blue-800';
      case 'ergo':
        return 'bg-purple-100 text-purple-800';
      case 'logo':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!currentExercise) {
    return <div className="p-6">Exercice non trouvé</div>;
  }

  // Pre-session pain evaluation modal
  if (showPreSessionPain) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl max-w-2xl w-full p-8 shadow-xl">
          <h2 className="text-3xl font-bold text-gray-900 mb-4 text-center">
            Comment évaluez-vous votre douleur avant de commencer ?
          </h2>
          
          {/* Emoji display */}
          <div className="text-center my-8">
            <div className="text-8xl mb-4">{painEmojis[preSessionPain]}</div>
            <p className="text-2xl font-bold text-gray-900">
              {preSessionPain === 0 ? 'Aucune' : preSessionPain === 10 ? 'Insupportable' : `${preSessionPain}/10`}
            </p>
          </div>

          {/* Slider */}
          <div className="mb-8">
            <input
              type="range"
              min="0"
              max="10"
              value={preSessionPain}
              onChange={(e) => setPreSessionPain(Number(e.target.value))}
              className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#00BAA8]"
            />
            <div className="flex justify-between text-sm text-gray-500 mt-2">
              <span>😊 Aucune</span>
              <span>😱 Insupportable</span>
            </div>
          </div>

          <button
            onClick={startPreSession}
            className="w-full px-6 py-4 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-semibold text-lg"
          >
            Commencer la séance
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 md:ml-64">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={handleAbandon}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="hidden md:inline">Abandonner</span>
            </button>
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getTherapyColor(program.therapyType)}`}>
                {getTherapyLabel(program.therapyType)}
              </span>
            </div>
          </div>
          <h1 className="font-bold text-xl text-gray-900 mb-4">{program.title}</h1>

          {/* Collapsible Progress Section */}
          <button
            onClick={() => setShowProgressDetails(!showProgressDetails)}
            className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Info className="w-5 h-5 text-gray-600" />
              <span className="font-medium text-gray-900">
                Exercice {currentExerciseIndex + 1} sur {totalExercises}
              </span>
            </div>
            {showProgressDetails ? (
              <ChevronUp className="w-5 h-5 text-gray-600" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-600" />
            )}
          </button>

          {/* Progress Details (Collapsible) */}
          {showProgressDetails && (
            <div className="mt-3 p-4 bg-white border border-gray-200 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                {sortedExercises.map((_, index) => (
                  <div
                    key={index}
                    className={`flex-1 h-1.5 rounded-full transition-colors ${
                      index < currentExerciseIndex
                        ? exerciseStatuses[index]?.status === 'completed'
                          ? 'bg-green-500'
                          : exerciseStatuses[index]?.status === 'skipped'
                          ? 'bg-yellow-500'
                          : 'bg-gray-300'
                        : index === currentExerciseIndex
                        ? 'bg-[#00BAA8]'
                        : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>
              <div className="space-y-2">
                {sortedExercises.map((programEx, index) => {
                  const exercise = mockExercises.find(e => e.id === programEx.exerciseId);
                  if (!exercise) return null;
                  const status = exerciseStatuses[index]?.status;
                  const isCurrent = index === currentExerciseIndex;

                  return (
                    <div
                      key={programEx.exerciseId}
                      className={`text-sm flex items-center gap-2 ${
                        isCurrent ? 'font-semibold text-[#00BAA8]' : 'text-gray-600'
                      }`}
                    >
                      <span>{index + 1}.</span>
                      <span className="flex-1">{exercise.title}</span>
                      {status === 'completed' && <span className="text-green-600">✓</span>}
                      {status === 'skipped' && <span className="text-yellow-600">→</span>}
                      {status === 'not-attempted' && <span className="text-gray-400">○</span>}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Video Player with instruction */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
          <div className="p-4 bg-gray-50 border-b border-gray-200">
            <p className="text-center text-gray-700 font-medium">
              Voici le mouvement que vous allez faire.
            </p>
          </div>
          <div className="aspect-video bg-gray-900 flex items-center justify-center">
            <Play className="w-24 h-24 text-white/50" />
          </div>
        </div>

        {/* Exercise Info */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-3">{currentExercise.title}</h2>
          <p className="text-lg text-gray-700 mb-6">{currentExercise.description}</p>

          {/* Exercise Parameters */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {currentProgramEx.sets && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Séries</p>
                <p className="text-2xl font-bold text-gray-900">{currentProgramEx.sets}</p>
              </div>
            )}
            {currentProgramEx.reps && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Répétitions</p>
                <p className="text-2xl font-bold text-gray-900">{currentProgramEx.reps}</p>
              </div>
            )}
            {currentProgramEx.duration && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Durée</p>
                <p className="text-2xl font-bold text-gray-900">
                  {Math.floor(currentProgramEx.duration / 60)} min
                </p>
              </div>
            )}
            {currentProgramEx.weight && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Charge</p>
                <p className="text-2xl font-bold text-gray-900">{currentProgramEx.weight} kg</p>
              </div>
            )}
          </div>

          {/* Timer for duration-based exercises */}
          {currentProgramEx.duration && (
            <div className="mb-6">
              {!isTimerRunning && timeRemaining === 0 ? (
                <button
                  onClick={startTimer}
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold text-lg"
                >
                  <Play className="w-6 h-6" />
                  Commencer l'exercice
                </button>
              ) : (
                <div className="text-center">
                  <div className="text-6xl font-bold text-[#00BAA8] mb-4">
                    {formatTime(timeRemaining)}
                  </div>
                  {isTimerRunning ? (
                    <button
                      onClick={() => setIsTimerRunning(false)}
                      className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                    >
                      Pause
                    </button>
                  ) : timeRemaining > 0 ? (
                    <button
                      onClick={() => setIsTimerRunning(true)}
                      className="px-6 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
                    >
                      Reprendre
                    </button>
                  ) : (
                    <p className="text-green-600 font-semibold text-lg">Exercice terminé !</p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="space-y-3">
            <button
              onClick={handleNext}
              className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-semibold text-lg"
            >
              {isLastExercise ? 'Terminer la séance' : 'Fait ! Passer au suivant'}
            </button>
            <button
              onClick={handleSkip}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <SkipForward className="w-5 h-5" />
              Passer cet exercice
            </button>
          </div>
        </div>

        {/* Warning */}
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-orange-900">
              <strong>Douleur trop forte ?</strong> N'hésitez pas à abandonner la séance si nécessaire en cliquant sur la flèche retour.
            </p>
          </div>
        </div>
      </div>

      {/* Skip Modal */}
      {showSkipModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">Passer cet exercice ?</h2>
            </div>
            <div className="p-6">
              <p className="text-gray-700 mb-4">
                Pourquoi passez-vous cet exercice ? (optionnel)
              </p>
              <textarea
                value={skipReason}
                onChange={(e) => setSkipReason(e.target.value)}
                rows={3}
                placeholder="Ex: Trop fatigué, manque de temps..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
              />
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => {
                  setShowSkipModal(false);
                  setSkipReason('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={confirmSkip}
                className="flex-1 px-4 py-2 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors"
              >
                Valider et continuer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Abandon Modal */}
      {showAbandonModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">Voulez-vous vraiment arrêter la séance ici ?</h2>
            </div>
            <div className="p-6">
              <p className="text-gray-700">
                Les exercices restants seront marqués comme non tentés.
              </p>
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => setShowAbandonModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Non, continuer
              </button>
              <button
                onClick={confirmAbandon}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Oui, abandonner
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Feedback Modal */}
      {showFeedbackModal && (
        <FeedbackModal
          isAbandoned={isSessionAbandoned}
          preSessionPain={preSessionPain}
          exerciseStatuses={exerciseStatuses}
          onComplete={() => {
            // Créer une session fictive pour la modale
            const newSession = {
              id: `s${Date.now()}`,
              programId: program.id,
              patientId: patient.id,
              date: new Date(),
              status: isSessionAbandoned ? 'abandoned' as const : 'complete' as const,
              exercises: exerciseStatuses,
              feedback: { pain: 5, difficulty: 5 } // sera rempli par le modal
            };
            // Naviguer vers le dashboard avec la modale ouverte (simulé)
            navigate(`/patient/${patientId}`);
          }}
        />
      )}
    </div>
  );
}

// Feedback Modal Component
function FeedbackModal({
  isAbandoned,
  preSessionPain,
  exerciseStatuses,
  onComplete,
}: {
  isAbandoned: boolean;
  preSessionPain: number;
  exerciseStatuses: any[];
  onComplete: () => void;
}) {
  const [postSessionPain, setPostSessionPain] = useState(5);
  const [difficulty, setDifficulty] = useState(5);
  const [comment, setComment] = useState('');

  const handleSubmit = () => {
    // Save feedback (in real app, would save to backend)
    console.log({ preSessionPain, postSessionPain, difficulty, comment });
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">
            {isAbandoned ? 'Séance abandonnée' : 'Bravo ! Séance terminée'}
          </h2>
          <p className="text-gray-600 mt-2">
            {isAbandoned
              ? 'Merci de nous donner votre feedback'
              : 'Comment s\'est passée cette séance ?'}
          </p>
        </div>
        <div className="p-6 space-y-6">
          {/* Post-session Pain with Emojis */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3 text-center">
              Douleur après la séance
            </label>
            <div className="text-center mb-4">
              <div className="text-6xl">{painEmojis[postSessionPain]}</div>
              <p className="text-xl font-bold text-gray-900 mt-2">
                {postSessionPain === 0 ? 'Aucune' : postSessionPain === 10 ? 'Insupportable' : `${postSessionPain}/10`}
              </p>
            </div>
            <input
              type="range"
              min="0"
              max="10"
              value={postSessionPain}
              onChange={(e) => setPostSessionPain(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#00BAA8]"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>😊 Aucune</span>
              <span>😱 Insupportable</span>
            </div>
          </div>

          {/* Difficulty */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Niveau de difficulté: <span className="text-xl font-bold text-gray-900">{difficulty}/10</span>
            </label>
            <input
              type="range"
              min="0"
              max="10"
              value={difficulty}
              onChange={(e) => setDifficulty(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#00BAA8]"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Très facile</span>
              <span>Très difficile</span>
            </div>
          </div>

          {/* Comment */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Commentaire (optionnel)
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
              placeholder="Partagez votre ressenti..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00BAA8] focus:border-transparent"
            />
          </div>
        </div>
        <div className="p-6 border-t border-gray-200">
          <button
            onClick={handleSubmit}
            className="w-full px-6 py-3 bg-[#00BAA8] text-white rounded-lg hover:bg-[#008C7E] transition-colors font-semibold"
          >
            Terminer
          </button>
        </div>
      </div>
    </div>
  );
}
