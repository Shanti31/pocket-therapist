import { createBrowserRouter } from 'react-router';
import { RootLayout } from './layouts/RootLayout';
import { TherapistLayout } from './layouts/TherapistLayout';
import { PatientLayout } from './layouts/PatientLayout';

// Therapist Pages
import { TherapistDashboard } from './pages/therapist/Dashboard';
import { PatientsList } from './pages/therapist/PatientsList';
import { PatientDetail } from './pages/therapist/PatientDetail';
import { TemplatesLibrary } from './pages/therapist/TemplatesLibrary';
import { TemplateEditor } from './pages/therapist/TemplateEditor';
import { ExercisesLibrary } from './pages/therapist/ExercisesLibrary';

// Patient Pages
import { PatientDashboard } from './pages/patient/Dashboard';
import { SessionPlayer } from './pages/patient/SessionPlayer';
import { Progress } from './pages/patient/Progress';
import { Achievements } from './pages/patient/Achievements';

// Landing
import { Landing } from './pages/Landing';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: RootLayout,
    children: [
      {
        index: true,
        Component: Landing,
      },
      {
        path: 'therapist',
        Component: TherapistLayout,
        children: [
          {
            index: true,
            Component: TherapistDashboard,
          },
          {
            path: 'patients',
            Component: PatientsList,
          },
          {
            path: 'patients/:patientId',
            Component: PatientDetail,
          },
          {
            path: 'templates',
            Component: TemplatesLibrary,
          },
          {
            path: 'templates/:templateId',
            Component: TemplateEditor,
          },
          {
            path: 'templates/new',
            Component: TemplateEditor,
          },
          {
            path: 'exercises',
            Component: ExercisesLibrary,
          },
        ],
      },
      {
        path: 'patient/:patientId',
        Component: PatientLayout,
        children: [
          {
            index: true,
            Component: PatientDashboard,
          },
          {
            path: 'session/:programId',
            Component: SessionPlayer,
          },
          {
            path: 'progress',
            Component: Progress,
          },
          {
            path: 'achievements',
            Component: Achievements,
          },
        ],
      },
    ],
  },
]);
