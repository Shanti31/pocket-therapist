import { Outlet, Link, useLocation, useParams } from 'react-router';
import { Home, TrendingUp, Award } from 'lucide-react';

export function PatientLayout() {
  const location = useLocation();
  const { patientId } = useParams();

  const navigation = [
    { name: 'Accueil', href: `/patient/${patientId}`, icon: Home },
    { name: 'Progression', href: `/patient/${patientId}/progress`, icon: TrendingUp },
    { name: 'Mes Succès', href: `/patient/${patientId}/achievements`, icon: Award },
  ];

  const isActive = (href: string) => {
    return location.pathname === href;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Outlet />

      {/* Bottom Navigation - Mobile First */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 md:hidden">
        <div className="flex justify-around items-center">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'text-[#00BAA8]'
                    : 'text-gray-500'
                }`}
              >
                <Icon className="w-6 h-6" />
                <span className="text-xs">{item.name}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Sidebar Navigation - Desktop */}
      <aside className="hidden md:block w-64 bg-white border-r border-gray-200 fixed h-full">
        <div className="p-6">
          <h1 className="font-bold text-xl text-[#00BAA8]">Thérapeute de Poche</h1>
        </div>
        <nav className="px-4 space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'bg-[#00BAA8] text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.name}</span>
              </Link>
            );
          })}
        </nav>
      </aside>
    </div>
  );
}
