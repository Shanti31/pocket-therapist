import { Outlet, Link, useLocation } from 'react-router';
import { LayoutDashboard, Users, BookOpen, Dumbbell } from 'lucide-react';

export function TherapistLayout() {
  const location = useLocation();

  const navigation = [
    { name: 'Dashboard', href: '/therapist', icon: LayoutDashboard },
    { name: 'Patients', href: '/therapist/patients', icon: Users },
    { name: 'Templates', href: '/therapist/templates', icon: BookOpen },
    { name: 'Exercices', href: '/therapist/exercises', icon: Dumbbell },
  ];

  const isActive = (href: string) => {
    if (href === '/therapist') {
      return location.pathname === href;
    }
    return location.pathname.startsWith(href);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 fixed h-full">
        <div className="p-6">
          <h1 className="font-bold text-xl text-[#00BAA8]">Thérapeute de Poche</h1>
          <p className="text-sm text-gray-500 mt-1">Interface Thérapeute</p>
        </div>
        <nav className="px-4 space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'bg-[#00BAA8] text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.name}</span>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main content */}
      <main className="flex-1 ml-64">
        <Outlet />
      </main>
    </div>
  );
}
