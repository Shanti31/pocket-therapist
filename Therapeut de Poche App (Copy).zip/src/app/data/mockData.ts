// Mock data pour le prototype Thérapeute de Poche

import { 
  Exercise, 
  ProgramTemplate, 
  CustomProgram, 
  Patient, 
  Session, 
  Alert,
  SessionStatus,
  ExerciseStatus 
} from '../types';

// Exercices de la bibliothèque
export const mockExercises: Exercise[] = [
  {
    id: 'ex1',
    title: 'Flexion de hanche',
    description: 'Allongé sur le dos, pliez le genou et ramenez-le vers la poitrine',
    videoUrl: 'https://example.com/video1.mp4',
    therapyType: 'physio',
    defaultSets: 3,
    defaultReps: 10,
  },
  {
    id: 'ex2',
    title: 'Extension de genou',
    description: 'Assis, tendez la jambe devant vous',
    videoUrl: 'https://example.com/video2.mp4',
    therapyType: 'physio',
    defaultSets: 3,
    defaultReps: 12,
  },
  {
    id: 'ex3',
    title: 'Abduction de hanche',
    description: 'Debout, levez la jambe sur le côté',
    videoUrl: 'https://example.com/video3.mp4',
    therapyType: 'physio',
    defaultSets: 3,
    defaultReps: 10,
    defaultWeight: 2,
  },
  {
    id: 'ex4',
    title: 'Marche assistée',
    description: 'Marchez avec un déambulateur sur 10 mètres',
    videoUrl: 'https://example.com/video4.mp4',
    therapyType: 'physio',
    defaultDuration: 300, // 5 minutes
  },
  {
    id: 'ex5',
    title: 'Préhension fine',
    description: 'Saisir de petits objets avec le pouce et l\'index',
    videoUrl: 'https://example.com/video5.mp4',
    therapyType: 'ergo',
    defaultSets: 2,
    defaultReps: 15,
  },
  {
    id: 'ex6',
    title: 'Coordination main-œil',
    description: 'Empiler des cubes de différentes tailles',
    videoUrl: 'https://example.com/video6.mp4',
    therapyType: 'ergo',
    defaultDuration: 600, // 10 minutes
  },
  {
    id: 'ex7',
    title: 'Articulation phonétique',
    description: 'Répéter des syllabes complexes',
    videoUrl: 'https://example.com/video7.mp4',
    therapyType: 'logo',
    defaultDuration: 900, // 15 minutes
  },
  {
    id: 'ex8',
    title: 'Respiration diaphragmatique',
    description: 'Exercice de respiration profonde',
    videoUrl: 'https://example.com/video8.mp4',
    therapyType: 'logo',
    defaultSets: 5,
    defaultReps: 5,
  },
];

// Templates de programmes
export const mockTemplates: ProgramTemplate[] = [
  {
    id: 'tpl1',
    title: 'Post-op Hanche',
    description: 'Programme de rééducation après opération de la hanche',
    therapyType: 'physio',
    exercises: [
      { exerciseId: 'ex1', order: 1, sets: 3, reps: 10 },
      { exerciseId: 'ex2', order: 2, sets: 3, reps: 12 },
      { exerciseId: 'ex3', order: 3, sets: 3, reps: 10, weight: 2 },
      { exerciseId: 'ex4', order: 4, duration: 300 },
    ],
    createdAt: new Date('2026-03-01'),
  },
  {
    id: 'tpl2',
    title: 'Rééducation de la main',
    description: 'Programme pour retrouver la motricité fine',
    therapyType: 'ergo',
    exercises: [
      { exerciseId: 'ex5', order: 1, sets: 2, reps: 15 },
      { exerciseId: 'ex6', order: 2, duration: 600 },
    ],
    createdAt: new Date('2026-02-15'),
  },
  {
    id: 'tpl3',
    title: 'Rééducation de la parole',
    description: 'Programme de logopédie pour améliorer l\'articulation',
    therapyType: 'logo',
    exercises: [
      { exerciseId: 'ex7', order: 1, duration: 900 },
      { exerciseId: 'ex8', order: 2, sets: 5, reps: 5 },
    ],
    createdAt: new Date('2026-02-20'),
  },
];

// Sessions récentes pour les patients
const createSession = (
  id: string,
  programId: string,
  patientId: string,
  date: Date,
  status: SessionStatus,
  exercises: { exerciseId: string; status: ExerciseStatus; skipReason?: string }[],
  feedback?: { pain: number; difficulty: number; comment?: string }
): Session => ({
  id,
  programId,
  patientId,
  date,
  status,
  exercises,
  feedback,
});

// Patients
export const mockPatients: Patient[] = [
  {
    id: 'p1',
    firstName: 'Jean',
    lastName: 'Dupont',
    pathology: 'Post-op Hanche Droite',
    programs: [
      {
        id: 'cp1',
        templateId: 'tpl1',
        patientId: 'p1',
        title: 'Post-op Hanche',
        description: 'Programme de rééducation après opération de la hanche',
        therapyType: 'physio',
        exercises: [
          { exerciseId: 'ex1', order: 1, sets: 3, reps: 10 },
          { exerciseId: 'ex2', order: 2, sets: 3, reps: 12 },
          { exerciseId: 'ex3', order: 3, sets: 3, reps: 10, weight: 2 },
          { exerciseId: 'ex4', order: 4, duration: 300 },
        ],
        frequency: { perWeek: 5 },
        createdAt: new Date('2026-03-10'),
      },
      {
        id: 'cp2',
        templateId: 'tpl2',
        patientId: 'p1',
        title: 'Rééducation de la main',
        description: 'Programme pour retrouver la motricité fine',
        therapyType: 'ergo',
        exercises: [
          { exerciseId: 'ex5', order: 1, sets: 2, reps: 15 },
          { exerciseId: 'ex6', order: 2, duration: 600 },
        ],
        frequency: { perWeek: 3 },
        createdAt: new Date('2026-03-10'),
      },
    ],
    sessions: [
      createSession(
        's1',
        'cp1',
        'p1',
        new Date('2026-03-20T10:00:00'),
        'complete',
        [
          { exerciseId: 'ex1', status: 'completed' },
          { exerciseId: 'ex2', status: 'completed' },
          { exerciseId: 'ex3', status: 'completed' },
          { exerciseId: 'ex4', status: 'completed' },
        ],
        { pain: 2, difficulty: 3, comment: 'Séance très bien passée' }
      ),
      createSession(
        's2',
        'cp2',
        'p1',
        new Date('2026-03-19T14:00:00'),
        'partial',
        [
          { exerciseId: 'ex5', status: 'completed' },
          { exerciseId: 'ex6', status: 'skipped', skipReason: 'Trop fatigué' },
        ],
        { pain: 1, difficulty: 2 }
      ),
      createSession(
        's3',
        'cp1',
        'p1',
        new Date('2026-03-18T10:00:00'),
        'abandoned',
        [
          { exerciseId: 'ex1', status: 'completed' },
          { exerciseId: 'ex2', status: 'completed' },
          { exerciseId: 'ex3', status: 'not-attempted' },
          { exerciseId: 'ex4', status: 'not-attempted' },
        ],
        { pain: 7, difficulty: 8, comment: 'Douleur trop importante' }
      ),
      createSession(
        's4',
        'cp1',
        'p1',
        new Date('2026-03-17T10:00:00'),
        'complete',
        [
          { exerciseId: 'ex1', status: 'completed' },
          { exerciseId: 'ex2', status: 'completed' },
          { exerciseId: 'ex3', status: 'completed' },
          { exerciseId: 'ex4', status: 'completed' },
        ],
        { pain: 3, difficulty: 4 }
      ),
    ],
    createdAt: new Date('2026-03-10'),
  },
  {
    id: 'p2',
    firstName: 'Marie',
    lastName: 'Martin',
    pathology: 'AVC Ischémique',
    programs: [
      {
        id: 'cp3',
        templateId: 'tpl3',
        patientId: 'p2',
        title: 'Rééducation de la parole',
        description: 'Programme de logopédie pour améliorer l\'articulation',
        therapyType: 'logo',
        exercises: [
          { exerciseId: 'ex7', order: 1, duration: 900 },
          { exerciseId: 'ex8', order: 2, sets: 5, reps: 5 },
        ],
        frequency: { perWeek: 4 },
        createdAt: new Date('2026-03-12'),
      },
      {
        id: 'cp4',
        templateId: 'tpl1',
        patientId: 'p2',
        title: 'Mobilité générale',
        description: 'Programme de physiothérapie pour la mobilité',
        therapyType: 'physio',
        exercises: [
          { exerciseId: 'ex1', order: 1, sets: 2, reps: 8 },
          { exerciseId: 'ex2', order: 2, sets: 2, reps: 10 },
          { exerciseId: 'ex4', order: 3, duration: 180 },
        ],
        frequency: { perWeek: 5 },
        createdAt: new Date('2026-03-12'),
      },
    ],
    sessions: [
      createSession(
        's5',
        'cp3',
        'p2',
        new Date('2026-03-19T09:00:00'),
        'complete',
        [
          { exerciseId: 'ex7', status: 'completed' },
          { exerciseId: 'ex8', status: 'completed' },
        ],
        { pain: 0, difficulty: 5 }
      ),
      createSession(
        's6',
        'cp4',
        'p2',
        new Date('2026-03-18T15:00:00'),
        'complete',
        [
          { exerciseId: 'ex1', status: 'completed' },
          { exerciseId: 'ex2', status: 'completed' },
          { exerciseId: 'ex4', status: 'completed' },
        ],
        { pain: 8, difficulty: 7, comment: 'Beaucoup de douleur aujourd\'hui' }
      ),
    ],
    createdAt: new Date('2026-03-12'),
  },
  {
    id: 'p3',
    firstName: 'Pierre',
    lastName: 'Dubois',
    pathology: 'Fracture Poignet',
    programs: [
      {
        id: 'cp5',
        templateId: 'tpl2',
        patientId: 'p3',
        title: 'Rééducation de la main',
        description: 'Programme pour retrouver la motricité fine',
        therapyType: 'ergo',
        exercises: [
          { exerciseId: 'ex5', order: 1, sets: 3, reps: 12 },
          { exerciseId: 'ex6', order: 2, duration: 480 },
        ],
        frequency: { perWeek: 4 },
        createdAt: new Date('2026-03-15'),
      },
    ],
    sessions: [
      createSession(
        's7',
        'cp5',
        'p3',
        new Date('2026-03-20T11:00:00'),
        'partial',
        [
          { exerciseId: 'ex5', status: 'completed' },
          { exerciseId: 'ex6', status: 'skipped', skipReason: 'Manque de temps' },
        ],
        { pain: 4, difficulty: 5 }
      ),
    ],
    createdAt: new Date('2026-03-15'),
  },
];

// Alertes
export const mockAlerts: Alert[] = [
  {
    id: 'a1',
    patientId: 'p2',
    sessionId: 's6',
    pain: 8,
    date: new Date('2026-03-18T15:00:00'),
    acknowledged: false,
  },
];
