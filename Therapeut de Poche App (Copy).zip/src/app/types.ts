// Types pour l'application Thérapeute de Poche

export type TherapyType = 'physio' | 'ergo' | 'logo';

export type SessionStatus = 'complete' | 'partial' | 'abandoned' | 'pending';

export type ExerciseStatus = 'completed' | 'skipped' | 'not-attempted';

export interface Exercise {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  therapyType: TherapyType;
  defaultSets?: number;
  defaultReps?: number;
  defaultDuration?: number; // en secondes
  defaultWeight?: number; // en kg
}

export interface ProgramExercise {
  exerciseId: string;
  order: number;
  sets?: number;
  reps?: number;
  duration?: number;
  weight?: number;
}

export interface ProgramTemplate {
  id: string;
  title: string;
  description: string;
  therapyType: TherapyType;
  exercises: ProgramExercise[];
  createdAt: Date;
}

export interface CustomProgram {
  id: string;
  templateId: string;
  patientId: string;
  title: string;
  description: string;
  therapyType: TherapyType;
  exercises: ProgramExercise[];
  frequency: {
    perWeek?: number;
    perDay?: number;
  };
  createdAt: Date;
}

export interface SessionExercise {
  exerciseId: string;
  status: ExerciseStatus;
  skipReason?: string;
}

export interface SessionFeedback {
  pain: number; // 0-10
  difficulty: number; // 0-10
  comment?: string;
}

export interface Session {
  id: string;
  programId: string;
  patientId: string;
  date: Date;
  status: SessionStatus;
  exercises: SessionExercise[];
  feedback?: SessionFeedback;
}

export interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  pathology: string;
  programs: CustomProgram[];
  sessions: Session[];
  createdAt: Date;
}

export interface Alert {
  id: string;
  patientId: string;
  sessionId: string;
  pain: number;
  date: Date;
  acknowledged: boolean;
}
